// EduNews Admin Script
jQuery(document).ready(function($) {
    // Debug log for Select2 initialization
    console.log('Initializing Select2 for categories');
    
    // Auto-sync status checking
    let syncStatusInterval;
    let manualSyncInProgress = false; // Flag per evitare conflitti con il polling
    
    function checkSyncStatus() {
        $.ajax({
            url: edunews_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'edunews_check_sync_status',
                nonce: edunews_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    const data = response.data;
                    const $forceSyncButton = $('#force-sync');
                    const $lastSyncText = $('.last-sync strong');
                    const $nextSyncText = $('.next-sync strong');
                    
                    // Update last sync time
                    $lastSyncText.text(data.last_sync);
                    
                    // Update next sync time
                    if ($nextSyncText.length > 0) {
                        $nextSyncText.text(data.next_sync);
                    }
                    
                    // Update button state only if not manually triggered
                    if (!manualSyncInProgress) {
                        if (data.is_syncing) {
                            $forceSyncButton.prop('disabled', true).text('Sincronizzazione in corso...');
                        } else {
                            $forceSyncButton.prop('disabled', false).text('Forza sincronizzazione');
                        }
                    } else if (!data.is_syncing) {
                        // Se la sync è finita, rimuovi la flag e aggiorna il pulsante
                        manualSyncInProgress = false;
                        $forceSyncButton.prop('disabled', false).text('Forza sincronizzazione');
                    }
                }
            },
            error: function() {
                console.log('Errore nel controllo dello stato di sincronizzazione');
            }
        });
    }
    
    // Start sync status checking if we're on the right page
    if ($('#force-sync').length > 0) {
        // Check immediately
        checkSyncStatus();
        
        // Check every 10 seconds
        syncStatusInterval = setInterval(checkSyncStatus, 10000);
    }
    
    // Clear interval when leaving the page
    $(window).on('beforeunload', function() {
        if (syncStatusInterval) {
            clearInterval(syncStatusInterval);
        }
    });

    // Gestione checkbox "Mostra tutti gli articoli"
    $('#show_all_posts').on('change', function() {
        if($(this).is(':checked')) {
            $('#max_posts').val('0').prop('disabled', true);
        } else {
            $('#max_posts').val('10').prop('disabled', false);
        }
    });

    // Imposta lo stato iniziale della checkbox in base al valore nel campo max_posts
    if($('#max_posts').length) {
        var maxPosts = parseInt($('#max_posts').val());
        if(maxPosts === 0) {
            $('#show_all_posts').prop('checked', true);
            $('#max_posts').prop('disabled', true);
        }
    }
    
    // Inizializza Select2 per la selezione delle categorie
    $('.select2-categories').select2({
        placeholder: 'Seleziona le categorie',
        allowClear: true,
        width: '100%',
        minimumResultsForSearch: 0,
        language: {
            noResults: function() {
                console.log('No results found in Select2');
                return "Nessuna categoria trovata";
            },
            searching: function() {
                console.log('Searching in Select2');
                return "Ricerca in corso...";
            }
        },
        templateResult: function(data) {
            console.log('Select2 template result:', data);
            if (!data.id) return data.text;
            return $('<span>' + data.text + '</span>');
        },
        templateSelection: function(data) {
            console.log('Select2 template selection:', data);
            if (!data.id) return data.text;
            return $('<span>' + data.text + '</span>');
        }
    }).on('select2:open', function() {
        console.log('Select2 opened');
    }).on('select2:close', function() {
        console.log('Select2 closed');
    }).on('select2:select', function(e) {
        console.log('Select2 selected:', e.params.data);
    }).on('select2:unselect', function(e) {
        console.log('Select2 unselected:', e.params.data);
    });
    
    // Gestisce l'invio del form per assicurare che max_posts sia corretto
    $('#edunews-shortcode-form').on('submit', function(e) {
        if($('#show_all_posts').is(':checked')) {
            // Assicuriamoci che il valore sia 0 prima dell'invio
            $('#max_posts').val('0').prop('disabled', false);
        }
    });
    
    // Handle copy button click
    $('.copy-shortcode').on('click', function() {
        var shortcodeText = $(this).data('shortcode');
        
        // Create temporary input
        var tempInput = $('<input>');
        $('body').append(tempInput);
        tempInput.val(shortcodeText).select();
        document.execCommand('copy');
        tempInput.remove();
        
        // Show copied message
        var $button = $(this);
        var originalText = $button.text();
        $button.text('Copiato!');
        setTimeout(function() {
            $button.text(originalText);
        }, 2000);
    });

    // Notice dismissal
    $(document).on('click', '.notice-dismiss', function() {
        $(this).parent().fadeOut(300, function() {
            $(this).remove();
        });
    });
    
    // Gestisce il click sul pulsante "Modifica" nella lista degli shortcode
    $('.edit-shortcode').on('click', function() {
        const shortcodeId = $(this).data('shortcode-id');
        const name = $(this).data('name');
        const title = $(this).data('title');
        const displayMode = $(this).data('display-mode');
        
        // Costruire il form di modifica in un alert personalizzato
        const formHtml = `
            <div class="edit-shortcode-form" style="margin-bottom: 15px;">
                <div style="margin-bottom: 10px;">
                    <label for="edit-name" style="display: block; margin-bottom: 5px; font-weight: bold;">Nome Shortcode:</label>
                    <input type="text" id="edit-name" value="${name}" style="width: 100%; padding: 5px;">
                </div>
                <div style="margin-bottom: 10px;">
                    <label for="edit-title" style="display: block; margin-bottom: 5px; font-weight: bold;">Titolo:</label>
                    <input type="text" id="edit-title" value="${title || ''}" style="width: 100%; padding: 5px;">
                </div>
                <div style="margin-bottom: 10px;">
                    <label for="edit-display-mode" style="display: block; margin-bottom: 5px; font-weight: bold;">Modalità di visualizzazione:</label>
                    <select id="edit-display-mode" style="width: 100%; padding: 5px;">
                        <option value="slide" ${displayMode === 'slide' ? 'selected' : ''}>Slider</option>
                        <option value="grid" ${displayMode === 'grid' ? 'selected' : ''}>Griglia</option>
                        <option value="list" ${displayMode === 'list' ? 'selected' : ''}>Elenco</option>
                    </select>
                </div>
            </div>
        `;
        
        // Mostra un dialogo personalizzato
        $('<div></div>').html(formHtml).dialog({
            title: 'Modifica Shortcode',
            resizable: false,
            width: 400,
            modal: true,
            buttons: {
                "Salva": function() {
                    const newName = $('#edit-name').val();
                    const newTitle = $('#edit-title').val();
                    const newDisplayMode = $('#edit-display-mode').val();
                    
                    if (!newName) {
                        alert('Il nome dello shortcode è obbligatorio.');
                        return;
                    }
                    
                    // Salva le modifiche via AJAX
                    $.ajax({
                        url: edunews_admin.ajax_url,
                        type: 'POST',
                        data: {
                            action: 'edunews_update_shortcode_settings',
                            nonce: edunews_admin.nonce,
                            shortcode_id: shortcodeId,
                            name: newName,
                            title: newTitle,
                            display_mode: newDisplayMode
                        },
                        success: function(response) {
                            if (response.success) {
                                location.reload(); // Ricarica la pagina per vedere le modifiche
                            } else {
                                alert('Errore nell\'aggiornamento dello shortcode: ' + response.data.message);
                            }
                        },
                        error: function() {
                            alert('Errore nella richiesta AJAX');
                        }
                    });
                    
                    $(this).dialog("close");
                },
                "Annulla": function() {
                    $(this).dialog("close");
                }
            }
        });
    });
    
    // Gestione della ricerca
    $('#edunews-search-input').on('input', function() {
        var searchTerm = $(this).val().toLowerCase().trim();
        console.log('Searching for:', searchTerm);
        
        $('.edunews-table-row').each(function() {
            var $row = $(this);
            var title = $row.data('title').toLowerCase();
            var author = $row.data('author').toLowerCase();
            var category = $row.data('category').toLowerCase();
            
            console.log('Comparing:', {
                title: title,
                author: author,
                category: category,
                searchTerm: searchTerm
            });
            
            if (title.includes(searchTerm) || 
                author.includes(searchTerm) || 
                category.includes(searchTerm)) {
                $row.show();
            } else {
                $row.hide();
            }
        });
    });
    
    // Handle force sync button
    $('#force-sync').on('click', function() {
        var $button = $(this);
        
        // Set flag to prevent polling from overriding button state
        manualSyncInProgress = true;
        
        // Immediately show syncing state
        $button.prop('disabled', true).text('Sincronizzazione in corso...');
        
        console.log('Force sync clicked - button updated immediately');
        
        $.ajax({
            url: edunews_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'edunews_force_sync',
                nonce: edunews_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    console.log('Sincronizzazione forzata avviata: ' + response.data.message);
                    // The status will be updated automatically by the polling
                } else {
                    alert(response.data.message);
                    // Reset button state and flag on error
                    manualSyncInProgress = false;
                    $button.prop('disabled', false).text('Forza sincronizzazione');
                }
            },
            error: function() {
                alert('Errore durante la sincronizzazione');
                // Reset button state and flag on error
                manualSyncInProgress = false;
                $button.prop('disabled', false).text('Forza sincronizzazione');
            }
        });
    });
    
    // Handle clear sync transient button (debug)
    $('#clear-sync').on('click', function() {
        var $button = $(this);
        var originalText = $button.text();
        
        $button.prop('disabled', true).text('🔄 Pulendo...');
        
        $.ajax({
            url: edunews_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'edunews_clear_sync_transient',
                nonce: edunews_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    console.log('Sync transient cleared: ' + response.data.message);
                    alert('Status di sincronizzazione resettato!');
                    // Force check sync status immediately to update all UI elements
                    if (typeof checkSyncStatus === 'function') {
                        checkSyncStatus();
                    }
                } else {
                    alert('Errore: ' + response.data.message);
                }
            },
            error: function() {
                alert('Errore durante il reset dello status');
            },
            complete: function() {
                $button.prop('disabled', false).text(originalText);
            }
        });
    });
}); 