// === script.js ===
jQuery(document).ready(function($) {
    // Gestione di più istanze
    const instanceMap = new Map();
    
    const isSplide = typeof Splide !== 'undefined';
    const isSwiper = typeof Swiper !== 'undefined';

    function waitForImages(selector, callback) {
        const images = $(selector + ' img');
        let loaded = 0;

        if (images.length === 0) {
            callback();
            return;
        }

        images.each(function () {
            if (this.complete) {
                loaded++;
                if (loaded === images.length) callback();
            } else {
                $(this).on('load', function () {
                    loaded++;
                    if (loaded === images.length) callback();
                }).on('error', function() {
                    loaded++;
                    if (loaded === images.length) callback();
                });
            }
        });
    }

    function initSplideSlider(element) {
        if (!element.classList.contains('is-initialized')) {
            // Ottieni l'ID dell'istanza
            const instanceId = element.dataset.instance || '';
            
            // Verifica se esiste già un'istanza per questo slider
            if (instanceMap.has(instanceId)) {
                const existingInstance = instanceMap.get(instanceId);
                if (typeof existingInstance.destroy === 'function') {
                    existingInstance.destroy();
                }
            }
            
            // Crea una nuova istanza Splide
            const splideInstance = new Splide(element, {
                perPage: 4,
                perMove: 1,
                gap: '2rem',
                pagination: true,
                arrows: true,
                autoHeight: true,
                breakpoints: {
                    1024: { perPage: 3, gap: '1.5rem' },
                    768: { perPage: 2, gap: '1rem' },   
                    640: { 
                        perPage: 1, 
                        fixedWidth: '85%',
                        focus: 'center', 
                        gap: '1.5rem',
                        padding: 0,
                        trimSpace: false,
                        arrows: true,
                        pagination: true
                    }
                }
            }).mount();
            
            // Salva l'istanza nella mappa
            instanceMap.set(instanceId, splideInstance);
            element.classList.add('is-initialized');
        }
    }

    function initSliders() {
        // Inizializza tutti gli slider Splide
        if (isSplide) {
            const splideElements = document.querySelectorAll('.edunews-splide:not(.is-initialized)');
            splideElements.forEach(function(element) {
                waitForImages('.' + element.dataset.instance, function() {
                    initSplideSlider(element);
                });
            });
        }
        
        // Supporto legacy per Swiper
        if (isSwiper) {
            const swiperElements = document.querySelectorAll('.edunews-swiper:not(.swiper-initialized)');
            swiperElements.forEach(function(element) {
                const instanceId = element.dataset.instance || '';
                
                if (instanceMap.has(instanceId)) {
                    const existingInstance = instanceMap.get(instanceId);
                    if (typeof existingInstance.destroy === 'function') {
                        existingInstance.destroy(true, true);
                    }
                }
                
                const swiperInstance = new Swiper(element, {
                slidesPerView: 4,
                    spaceBetween: 40,
                    autoHeight: true,
                    observer: true,
                    observeParents: true,
                navigation: {
                        nextEl: element.querySelector('.swiper-button-next'),
                        prevEl: element.querySelector('.swiper-button-prev'),
                },
                pagination: {
                        el: element.querySelector('.swiper-pagination'),
                    clickable: true,
                },
                breakpoints: {
                        1024: { slidesPerView: 4, spaceBetween: 40 },
                        768: { slidesPerView: 2, spaceBetween: 30 },
                        0: { slidesPerView: 1, spaceBetween: 20 }
                }
            });
                
                instanceMap.set(instanceId, swiperInstance);
        });
    }
    }

    // Inizializza gli slider che sono già nel DOM (renderizzati da PHP)
    initSliders();
    
    // Gestione per ciascuna istanza separatamente
    $('.edunews-wrapper').each(function() {
        const $wrapper = $(this);
        const instanceId = $wrapper.data('instance-id') || '';
        const shortcodeId = $wrapper.data('shortcode-id') || '';
        
        $.post(edunews_data.ajax_url, { 
            action: 'edunews_load_articles',
            instance_id: instanceId,
            shortcode_id: shortcodeId
        }, function(response) {
        if (response.success) {
                // Qui potremmo gestire l'aggiornamento dinamico dei contenuti
                // se necessario in futuro
                initSliders();
            }
        }).fail(function() {
            console.error('Chiamata AJAX fallita per l\'istanza ' + instanceId);
        });
    });
});
