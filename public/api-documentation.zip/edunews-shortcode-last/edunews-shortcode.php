<?php
/**
 * Plugin Name: EduNews Post
 * Description: Mostra articoli di edunews24.it.
 * Version: 1.0
 * Author: ERSAF (ersaf.it)
 */

if (!defined('ABSPATH')) {
    exit;
}

require_once plugin_dir_path(__FILE__) . 'admin-page.php';

add_action('wp_enqueue_scripts', function() {
    wp_enqueue_style('splide-css', 'https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/css/splide.min.css');
    wp_enqueue_script('splide-js', 'https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/js/splide.min.js', [], null, true);

    wp_enqueue_style('edunews-style', plugin_dir_url(__FILE__) . 'assets/style.css');
    wp_enqueue_script('edunews-ajax', plugin_dir_url(__FILE__) . 'assets/script.js', ['jquery'], null, true);

    wp_localize_script('edunews-ajax', 'edunews_data', [
        'ajax_url' => admin_url('admin-ajax.php'),
    ]);
});

add_shortcode('edunews_articles', 'edunews_render_articles');
function edunews_render_articles($atts) {
    // Questa è la funzione originale che usa l'API direttamente e l'ID shortcode
    // La lasceremo commentata o la rimuoveremo se la nuova edunews_articles_shortcode la sostituisce completamente.
    // Per ora, ci assicuriamo che la logica dell'ID non venga usata.

    $atts_original = shortcode_atts(
        array(
            'category' => '', // Questo potrebbe essere 'categories' a seconda della definizione effettiva
            'title'    => '',
            'display_mode' => 'slide',
            // 'id'       => '', // Rimuoviamo l'ID come parametro che carica configurazioni
            'max_posts' => 10
        ),
        $atts,
        'edunews_articles'
    );

    // Rimuoviamo completamente la logica che carica impostazioni da 'id'
    // $shortcode_id = sanitize_text_field($atts_original['id']); 
    // if (!empty($shortcode_id)) { ... } // Tutta questa sezione viene eliminata

    $filter_categories_str = isset($atts_original['category']) ? $atts_original['category'] : (isset($atts_original['categories']) ? $atts_original['categories'] : '');
    $filter_categories = !empty($filter_categories_str) ? array_map('trim', explode(',', $filter_categories_str)) : [];
    
    $title = sanitize_text_field($atts_original['title']);
    $display_mode = sanitize_text_field($atts_original['display_mode']);
    $max_posts = intval($atts_original['max_posts']);

    // Il resto della logica che recupera articoli dall'API e li renderizza rimane qui,
    // ma NON deve dipendere da un ID shortcode per le sue configurazioni.
    // Le configurazioni (categorie, titolo, display_mode, max_posts) vengono solo dagli attributi passati.

    $cached_data = get_transient('edunews_articles_cache');
    $all_articles_from_source = [];

    if (!$cached_data) {
        $response = wp_remote_get("https://edunews24.it/api/articles");
        if (is_wp_error($response)) {
            return '<p>Errore nel caricamento articoli.</p>';
        }
        $body = wp_remote_retrieve_body($response);
        $decoded_body = json_decode($body, true);

        if (!is_array($decoded_body)) {
             return '<p>Errore: dati API non validi.</p>';
        }
        $all_articles_from_source = $decoded_body;
        
        // Ordina gli articoli per published_at DESC (più recenti prima)
        usort($all_articles_from_source, function($a, $b) {
            if (!isset($a['published_at']) || !isset($b['published_at'])) {
                return 0;
            }
            return strtotime($b['published_at']) - strtotime($a['published_at']);
        });
        
        set_transient('edunews_articles_cache', $all_articles_from_source, 15 * MINUTE_IN_SECONDS);
        #error_log('EduNews RENDER: Caricati e ordinati ' . count($all_articles_from_source) . ' articoli dall\'API');
    } else {
        $all_articles_from_source = $cached_data;
        #error_log('EduNews RENDER: Utilizzando ' . count($all_articles_from_source) . ' articoli dalla cache');
    }

    #error_log('EDUNEWS DEBUG - Filtro categorie: ' . print_r($filter_categories, true));
    #error_log('EDUNEWS DEBUG - Articoli disponibili: ' . print_r($all_articles_from_source, true));

    $filtered_articles = $all_articles_from_source;

    if (!empty($filter_categories)) {
        $filtered_articles = array_filter($filtered_articles, function($article) use ($filter_categories) {
            if (!isset($article['category_slug'])) {
                return false;
            }
            return in_array($article['category_slug'], $filter_categories);
        });
    }
    
    // Ordina gli articoli per data di pubblicazione (più recenti prima)
    usort($filtered_articles, function($a, $b) {
        return strtotime($b['published_at']) - strtotime($a['published_at']);
    });
    
    // Limita il numero di articoli
    $filtered_articles = array_slice($filtered_articles, 0, $max_posts);
    
    $articles_to_display = array_values($filtered_articles);

    $instance_id = 'edunews-' . mt_rand(1000, 9999);
    
    $html = '<div class="edunews-wrapper" data-instance-id="' . esc_attr($instance_id) . '" data-shortcode-id="' . esc_attr($shortcode_id) . '">';
    
    if (!empty($title)) {
        $html .= '<h2 class="edunews-title">' . esc_html($title) . '</h2>';
    }
    
    if (empty($articles_to_display)) {
        if (!empty($shortcode_id)) {
            $html .= '<p class="edunews-empty-message">Nessun articolo trovato per i filtri specificati.</p>';
        } else {
            $html .= '<p class="edunews-empty-message">Nessun articolo trovato per i filtri specificati.</p>';
        }
        $html .= '</div>';
        return $html;
    }
    
    switch ($display_mode) {
        case 'grid':
            $html .= edunews_render_grid($articles_to_display, $instance_id);
            break;
        case 'list':
            $html .= edunews_render_list($articles_to_display, $instance_id);
            break;
        case 'slide':
        default:
            $html .= edunews_render_slider($articles_to_display, $instance_id);
            break;
    }
    
    $html .= '</div>';

    return $html;
}

function edunews_render_slider($articles, $instance_id = '') {
    // Limita il numero di articoli a 50 per lo slider
    $articles = array_slice($articles, 0, 50);
    
    $instance_class = !empty($instance_id) ? ' ' . $instance_id : '';
    
    $html = '<div class="splide edunews-splide' . $instance_class . '" data-instance="' . esc_attr($instance_id) . '">';
    $html .= '<div class="splide__track">';
    $html .= '<ul class="splide__list">';

    $index = 0;
    foreach ($articles as $article) {
        $is_first_page = ($index < 4);
        $loading_attr = $is_first_page ? '' : 'loading="lazy"';

        $html .= '<li class="splide__slide">';
        $html .= '<div class="edunews-article">';
        $html .= '<img src="' . esc_url($article['image_url']) . '" alt="" ' . $loading_attr . '>';

        $category_slug = isset($article['category_slug']) ? $article['category_slug'] : '';
        $slug = isset($article['slug']) ? $article['slug'] : '';
        $link = 'https://edunews24.it/' . $category_slug . '/' . $slug;

        // Usa title_summary se disponibile, altrimenti usa title
        $title_to_use = isset($article['title_summary']) && !empty($article['title_summary']) ? $article['title_summary'] : $article['title'];
        $html .= '<h3><a href="' . esc_url($link) . '" target="_blank">' . esc_html($title_to_use) . '</a></h3>';
        // Usa summary se disponibile, altrimenti usa excerpt come fallback
        $content_to_use = isset($article['summary']) && !empty($article['summary']) ? $article['summary'] : $article['excerpt'];
        $html .= '<div class="edunews-content">' . edunews_markdown_to_html($content_to_use) . '</div>';
        $html .= '<small>' . esc_html(date('d/m/Y', strtotime($article['published_at']))) . ' - ' . esc_html($article['category']) . '</small>';
        $html .= '</div></li>';

        $index++;
    }

    $html .= '</ul>';
    $html .= '</div>';
    $html .= '</div>';

    $html .= '<script>
        document.addEventListener("DOMContentLoaded", function() {
            var splideElement = document.querySelector(".edunews-splide.' . edunews_sanitize_js_id($instance_id) . '");
            if (splideElement && !splideElement.classList.contains("is-initialized")) {
                new Splide(splideElement, {
                    perPage: 4,
                    perMove: 1,
                    gap: "2rem",
                    pagination: true,
                    arrows: true,
                    autoHeight: true,
                    breakpoints: {
                        1024: { perPage: 3, gap: "1.5rem" }, 
                        768: { perPage: 2, gap: "1rem" },   
                        640: { 
                            perPage: 1, 
                            fixedWidth: "85%",
                            focus: "center", 
                            gap: "1.5rem",
                            padding: 0,
                            trimSpace: false,
                            arrows: true,
                            pagination: true
                        }
                    }
                }).mount();
                splideElement.classList.add("is-initialized");
            }
        });
    </script>';

    return $html;
}

function edunews_render_grid($articles, $instance_id = '') {
    $instance_class = !empty($instance_id) ? ' ' . $instance_id : '';
    
    $html = '<div class="edunews-grid' . $instance_class . '" data-instance="' . esc_attr($instance_id) . '">';
    
    foreach ($articles as $article) {
        $category_slug = isset($article['category_slug']) ? $article['category_slug'] : '';
        $slug = isset($article['slug']) ? $article['slug'] : '';
        $link = 'https://edunews24.it/' . $category_slug . '/' . $slug;
        
        $html .= '<div class="edunews-grid-item">';
        $html .= '<div class="edunews-article">';
        $html .= '<img src="' . esc_url($article['image_url']) . '" alt="" loading="lazy">';
        // Usa title_summary se disponibile, altrimenti usa title
        $title_to_use = isset($article['title_summary']) && !empty($article['title_summary']) ? $article['title_summary'] : $article['title'];
        $html .= '<h3><a href="' . esc_url($link) . '" target="_blank">' . esc_html($title_to_use) . '</a></h3>';
        // Usa summary se disponibile, altrimenti usa excerpt come fallback
        $content_to_use = isset($article['summary']) && !empty($article['summary']) ? $article['summary'] : $article['excerpt'];
        $html .= '<div class="edunews-content">' . edunews_markdown_to_html($content_to_use) . '</div>';
        $html .= '<small>' . esc_html(date('d/m/Y', strtotime($article['published_at']))) . ' - ' . esc_html($article['category']) . '</small>';
        $html .= '</div>';
        $html .= '</div>';
    }
    
    $html .= '</div>';
    return $html;
}

function edunews_render_list($articles, $instance_id = '') {
    $instance_class = !empty($instance_id) ? ' ' . $instance_id : '';
    
    $html = '<div class="edunews-list' . $instance_class . '" data-instance="' . esc_attr($instance_id) . '">';
    
    foreach ($articles as $article) {
        $category_slug = isset($article['category_slug']) ? $article['category_slug'] : '';
        $slug = isset($article['slug']) ? $article['slug'] : '';
        $link = 'https://edunews24.it/' . $category_slug . '/' . $slug;
        
        $html .= '<div class="edunews-list-item">';
        $html .= '<div class="edunews-article-list">';
        $html .= '<div class="edunews-list-image">';
        $html .= '<img src="' . esc_url($article['image_url']) . '" alt="" loading="lazy">';
        $html .= '</div>';
        $html .= '<div class="edunews-list-content">';
        $html .= '<small class="edunews-date-top">' . esc_html(date('d/m/Y', strtotime($article['published_at']))) . ' - ' . esc_html($article['category']) . '</small>';
        // Usa title_summary se disponibile, altrimenti usa title
        $title_to_use = isset($article['title_summary']) && !empty($article['title_summary']) ? $article['title_summary'] : $article['title'];
        $html .= '<h3><a href="' . esc_url($link) . '" target="_blank">' . esc_html($title_to_use) . '</a></h3>';
        // Usa summary se disponibile, altrimenti usa excerpt come fallback
        $content_to_use = isset($article['summary']) && !empty($article['summary']) ? $article['summary'] : $article['excerpt'];
        $html .= '<div class="edunews-content">' . edunews_markdown_to_html($content_to_use) . '</div>';
        $html .= '</div>';
        $html .= '</div>';
        $html .= '</div>';
    }
    
    $html .= '</div>';
    return $html;
}

add_action('wp_ajax_edunews_load_articles', 'edunews_load_articles');
add_action('wp_ajax_nopriv_edunews_load_articles', 'edunews_load_articles');
function edunews_load_articles() {
    $filter_category_slug = isset($_POST['category']) ? sanitize_text_field($_POST['category']) : '';
    $instance_id = isset($_POST['instance_id']) ? sanitize_text_field($_POST['instance_id']) : '';
    $shortcode_id = isset($_POST['shortcode_id']) ? sanitize_text_field($_POST['shortcode_id']) : '';
    
    $cached_data = get_transient('edunews_articles_cache');
    $all_articles_from_source = [];

    if ($cached_data) {
        $all_articles_from_source = $cached_data;
        #error_log('EduNews: Utilizzando articoli dalla cache (' . count($all_articles_from_source) . ' articoli)');
    } else {
        $response = wp_remote_get("https://edunews24.it/api/articles");
        if (is_wp_error($response)) {
            wp_send_json_error('Errore nel caricamento degli articoli.');
            return;
        }
        $body = wp_remote_retrieve_body($response);
        $decoded_body = json_decode($body, true);

        if (!is_array($decoded_body)) {
            wp_send_json_error('Formato dei dati API non valido.');
            return;
        }
        $all_articles_from_source = $decoded_body;
        
        // Ordina gli articoli per published_at DESC (più recenti prima)
        usort($all_articles_from_source, function($a, $b) {
            if (!isset($a['published_at']) || !isset($b['published_at'])) {
                return 0;
            }
            return strtotime($b['published_at']) - strtotime($a['published_at']);
        });
        
        set_transient('edunews_articles_cache', $all_articles_from_source, 15 * MINUTE_IN_SECONDS);
        #error_log('EduNews: Caricati e ordinati ' . count($all_articles_from_source) . ' articoli dall\'API');
    }

    $filtered_articles = $all_articles_from_source;

    $selected_post_ids = array();
    if (!empty($shortcode_id)) {
        $saved_shortcodes = get_option('edunews_saved_shortcodes', array());
        if (isset($saved_shortcodes[$shortcode_id]) && isset($saved_shortcodes[$shortcode_id]['post_ids'])) {
            $selected_post_ids = $saved_shortcodes[$shortcode_id]['post_ids'];
            
            if (empty($selected_post_ids)) {
                $filtered_articles = [];
            } else {
                $filtered_articles = array_filter($filtered_articles, function($article) use ($selected_post_ids) {
                    return isset($article['id']) && in_array($article['id'], $selected_post_ids);
                });
            }
        } else {
            $filtered_articles = [];
        }
    } else if (!empty($filter_category_slug) && is_array($filtered_articles)) {
        $filter_category_slug_array = array_map('trim', explode(',', $filter_category_slug));
        $filtered_articles = array_filter($filtered_articles, function($article) use ($filter_category_slug_array) {
            if (!isset($article['category_slug'])) {
                return false;
            }
            
            foreach ($filter_category_slug_array as $cat_slug) {
                if (strcasecmp($article['category_slug'], $cat_slug) === 0) {
                    return true;
                }
            }
            return false;
        });
    }

    $articles_to_send = array_values($filtered_articles);
    
    // Assicurati che gli articoli siano sempre ordinati per data di pubblicazione (più recenti prima)
    // Questo è importante perché i filtri potrebbero aver cambiato l'ordine
    usort($articles_to_send, function($a, $b) {
        if (!isset($a['published_at']) || !isset($b['published_at'])) {
            return 0;
        }
        return strtotime($b['published_at']) - strtotime($a['published_at']);
    });

    #error_log('EDUNEWS POST IDS ORDER: ' . implode(',', $selected_post_ids));
    #error_log('EduNews: Invio ' . count($articles_to_send) . ' articoli ordinati per data (più recenti prima)');

    wp_send_json_success([
        'articles' => $articles_to_send,
        'instance_id' => $instance_id
    ]);
}

function edunews_sanitize_js_id($id) {
    return preg_replace('/[^a-zA-Z0-9_-]/', '', $id);
}

// Register Custom Taxonomy for EduNews Articles
function edunews_register_taxonomy() {
    $labels = array(
        'name'              => _x( 'Categorie EduNews', 'taxonomy general name', 'edunews-shortcode' ),
        'singular_name'     => _x( 'Categoria EduNews', 'taxonomy singular name', 'edunews-shortcode' ),
        'search_items'      => __( 'Cerca Categorie', 'edunews-shortcode' ),
        'all_items'         => __( 'Tutte le Categorie', 'edunews-shortcode' ),
        'parent_item'       => __( 'Categoria Padre', 'edunews-shortcode' ),
        'parent_item_colon' => __( 'Categoria Padre:', 'edunews-shortcode' ),
        'edit_item'         => __( 'Modifica Categoria', 'edunews-shortcode' ),
        'update_item'       => __( 'Aggiorna Categoria', 'edunews-shortcode' ),
        'add_new_item'      => __( 'Aggiungi Nuova Categoria', 'edunews-shortcode' ),
        'new_item_name'     => __( 'Nome Nuova Categoria', 'edunews-shortcode' ),
        'menu_name'         => __( 'Categorie EduNews', 'edunews-shortcode' ),
    );

    $args = array(
        'hierarchical'      => true, // Set explicitly
        'labels'            => $labels,
        'public'            => true, // Ensure it's public if needed for visibility
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => 'edunews-category', 'with_front' => false ), // Explicitly set with_front
        'show_in_rest'      => true,
        'show_tagcloud'     => false, // Explicitly set
        'show_in_nav_menus' => true, // Explicitly set
        'show_in_quick_edit'=> true, // Explicitly set
    );

    register_taxonomy('edunews_category', 'edunews_article', $args);
    #error_log('EduNews: Taxonomy edunews_category registered with args: ' . print_r($args, true));

}
add_action('init', 'edunews_register_taxonomy');



// Register Custom Post Type for EduNews Articles
function edunews_register_post_type() {
    $labels = array(
        'name'               => 'Articoli EduNews',
        'singular_name'      => 'Articolo EduNews',
        'menu_name'          => 'Articoli EduNews',
        'add_new'            => null, // Rimuovo "Aggiungi Nuovo"
        'add_new_item'       => null, // Rimuovo "Aggiungi Nuovo Articolo"
        'edit_item'          => 'Visualizza Articolo',
        'new_item'           => null, // Rimuovo "Nuovo Articolo"
        'view_item'          => 'Visualizza Articolo',
        'search_items'       => 'Cerca Articoli',
        'not_found'          => 'Nessun articolo trovato',
        'not_found_in_trash' => 'Nessun articolo trovato nel cestino'
    );

    $args = array(
        'labels'              => $labels,
        'public'              => true,
        'has_archive'         => true,
        'publicly_queryable'  => true,
        'query_var'           => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_admin_bar'   => false, // Rimuovo dalla admin bar
        'rewrite'             => array(
            'slug' => 'edunews',
            'with_front' => true
        ),
        'capability_type'     => 'post',
        'capabilities'        => array(
            'create_posts' => false, // Impedisce la creazione di nuovi post
        ),
        'map_meta_cap'        => true, // Necessario per le capabilities personalizzate
        'hierarchical'        => false,
        'supports'            => array(), // Manteniamo vuoto per impedire l'editing
        'menu_position'       => 5,
        'menu_icon'           => 'dashicons-admin-post',
        'show_in_rest'        => false,
    );

    register_post_type('edunews_article', $args);
}
add_action('init', 'edunews_register_post_type');

// Add template support
function edunews_template_include($template) {
    // Se siamo su una pagina di tassonomia edunews_category
    if (is_tax('edunews_category')) {
        $custom_template = plugin_dir_path(__FILE__) . 'templates/taxonomy-edunews_category.php';
        if (file_exists($custom_template)) {
            return $custom_template;
        }
    }
    
    // Se siamo su un singolo articolo edunews
    if (is_singular('edunews_article')) {
        $custom_template = plugin_dir_path(__FILE__) . 'templates/single.php';
        if (file_exists($custom_template)) {
            return $custom_template;
        }
    }
    
    return $template;
}
add_filter('template_include', 'edunews_template_include');

// Flush rewrite rules on plugin activation
function edunews_activate() {
    edunews_register_post_type();
    edunews_register_taxonomy();
    
    // Pulisci la vecchia tassonomia edunews_subcategory se esiste
    edunews_cleanup_old_subcategory_taxonomy();
    
    flush_rewrite_rules();
    
    // Schedule the article update event every 20 minutes
    if (!wp_next_scheduled('edunews_update_articles_event')) {
        wp_schedule_event(time(), 'twenty_minutes', 'edunews_update_articles_event');
        #error_log('EduNews: Scheduled event set up on plugin activation (every 20 minutes). Next run: ' . date('Y-m-d H:i:s', wp_next_scheduled('edunews_update_articles_event')));
    }

    #error_log('EduNews: Plugin attivato. Scheduling auto-cleanup e sincronizzazione...');
    
    // Schedula cleanup completo tra 2 secondi (subito dopo attivazione)
    wp_schedule_single_event(time() + 2, 'edunews_immediate_cleanup_event');
    
    #error_log('EduNews: Auto-cleanup schedulato per 2 secondi. Plugin attivato rapidamente.');
}
register_activation_hook(__FILE__, 'edunews_activate');

// Flush rewrite rules on plugin deactivation
function edunews_deactivate() {
    flush_rewrite_rules();
    
    // Clear the scheduled event
    wp_clear_scheduled_hook('edunews_update_articles_event');
}
register_deactivation_hook(__FILE__, 'edunews_deactivate');

// Add custom schedule interval
function edunews_add_cron_interval($schedules) {
    $schedules['twenty_minutes'] = array(
        'interval' => 20 * MINUTE_IN_SECONDS,
        'display'  => 'Every 20 Minutes'
    );
    return $schedules;
}
add_filter('cron_schedules', 'edunews_add_cron_interval');

// Ensure scheduled event is set up
function edunews_ensure_scheduled_event() {
    $hook = 'edunews_update_articles_event';
    $interval = 'twenty_minutes';
    
    #error_log('EduNews CRON: Verifica evento programmato ogni 20 minuti...');
    
    // Se l'evento non è pianificato, pianificalo
    if (!wp_next_scheduled($hook)) {
        wp_schedule_event(time(), $interval, $hook);
        #error_log('EduNews CRON: Evento programmato per nuova installazione (ogni 20 minuti). Prossima esecuzione: ' . date('Y-m-d H:i:s', wp_next_scheduled($hook)));
    } 
    // Aggiunta: Se l'evento è pianificato ma con intervallo SBAGLIATO, ripianificalo
    else {
        $scheduled = wp_get_schedule($hook);
        if ($scheduled !== $interval) {
            wp_clear_scheduled_hook($hook); // Rimuovi il vecchio hook
            wp_schedule_event(time(), $interval, $hook); // Ripianifica con intervallo corretto
            #error_log('EduNews CRON: Riprogrammato evento con intervallo corretto (' . $interval . ' = 20 minuti). Prossima esecuzione: ' . date('Y-m-d H:i:s', wp_next_scheduled($hook)));
        }
        else {
            $next_run = wp_next_scheduled($hook);
            $time_until_next = $next_run - time();
            #error_log('EduNews CRON: Evento già programmato ogni 20 minuti. Prossima sincronizzazione: ' . date('Y-m-d H:i:s', $next_run) . ' (tra ' . round($time_until_next / 60, 1) . ' minuti)');
        }
    }
    
    // Verifica se wp-cron è abilitato
    if (defined('DISABLE_WP_CRON') && DISABLE_WP_CRON) {
        #error_log('EduNews CRON: ATTENZIONE - WP-CRON è disabilitato! La sincronizzazione automatica ogni 20 minuti non funzionerà.');
    } else {
        #error_log('EduNews CRON: WP-CRON è abilitato - sincronizzazione ogni 20 minuti attiva.');
    }
}
add_action('init', 'edunews_ensure_scheduled_event');

// Function to update articles
function edunews_update_articles() {
    #error_log('EduNews: Starting scheduled article update at ' . current_time('mysql'));
    
    // Check if update is already in progress
    if (get_transient('edunews_update_in_progress')) {
        #error_log('EduNews: Update already in progress, skipping');
        return;
    }
    
    // Set update in progress flag
    set_transient('edunews_update_in_progress', true, 120); // 2 minutes timeout for easier debugging
    
    // Aggiorna la data di ultima sincronizzazione (formato d/m/Y H:i:s)
    update_option('edunews_last_sync', current_time('d/m/Y H:i:s'));
    
    // Elimina la cache per forzare un aggiornamento completo
    delete_transient('edunews_articles_cache');
    delete_transient('edunews_categories_cache');
    delete_transient('edunews_subcategories_cache');
    
    // Rimuovi le categorie numeriche
    edunews_cleanup_numeric_categories();
    
    try {
        $response = wp_remote_get('https://edunews24.it/api/articles', array(
            'timeout' => 15,
            'sslverify' => false,
            'headers' => array(
                'Accept' => 'application/json'
            )
        ));
        
        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            #error_log('EduNews: API Error during scheduled update: ' . $error_message);
            throw new Exception('Errore di connessione API: ' . $error_message);
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            $error_message = 'API returned status code: ' . $response_code;
            #error_log('EduNews: ' . $error_message);
            throw new Exception($error_message);
        }

        $body = wp_remote_retrieve_body($response);
        $response_data = json_decode($body, true);
        
        // DEBUG: Log the raw API response structure
        #error_log('EduNews: Raw API response structure: ' . print_r(array_keys($response_data ?: []), true));
        
        // Check if the response has the expected structure
        if (!is_array($response_data)) {
            $error_message = 'Invalid API response format - not an array';
            #error_log('EduNews: ' . $error_message);
            throw new Exception($error_message);
        }
        
        // Handle different API response structures
        $articles = [];
        if (isset($response_data['articles']) && is_array($response_data['articles'])) {
            // New API structure: {"articles": [...]}
            $articles = $response_data['articles'];
            #error_log('EduNews: Using new API structure with articles wrapper');
        } elseif (isset($response_data[0]) && is_array($response_data[0])) {
            // Old API structure: directly an array of articles
            $articles = $response_data;
            #error_log('EduNews: Using old API structure - direct array');
        } else {
            $error_message = 'Invalid API response format - no articles found';
            #error_log('EduNews: ' . $error_message . '. Response keys: ' . print_r(array_keys($response_data), true));
            throw new Exception($error_message);
        }
        
        #error_log('EduNews: Found ' . count($articles) . ' articles during scheduled update');

        // Validate and process articles
        $valid_articles = [];
        foreach ($articles as $index => $article) {
            // Validate required fields and add missing ones
            if (!isset($article['title']) || empty($article['title'])) {
                #error_log('EduNews: Skipping article at index ' . $index . ' - missing title');
                continue;
            }
            
            // Generate missing slug if not present
            if (!isset($article['slug']) || empty($article['slug'])) {
                $article['slug'] = sanitize_title($article['title']) . '-' . ($index + 1); // Use title+index as fallback slug
                #error_log('EduNews: Generated slug ' . $article['slug'] . ' for article: ' . $article['title']);
            }
            
            // Ensure required fields have default values (slug già gestito sopra)
            $article['category_slug'] = $article['category_slug'] ?? 'general';
            $article['published_at'] = $article['published_at'] ?? current_time('Y-m-d\TH:i:s.uP');
            $article['excerpt'] = $article['excerpt'] ?? '';
            $article['category'] = $article['category'] ?? 'Generale';
            $article['image_url'] = $article['image_url'] ?? '';
            
            $valid_articles[] = $article;
        }
        
        if (empty($valid_articles)) {
            $error_message = 'No valid articles found in API response';
            #error_log('EduNews: ' . $error_message);
            throw new Exception($error_message);
        }

        // IMPORTANTE: Ordina gli articoli per published_at DESC (più recenti prima)
        usort($valid_articles, function($a, $b) {
            $time_a = strtotime($a['published_at']);
            $time_b = strtotime($b['published_at']);
            return $time_b - $time_a; // DESC: più recenti prima
        });
        
        #error_log('EduNews: Ordinati ' . count($valid_articles) . ' articoli per data di pubblicazione (più recenti prima) - NESSUN LIMITE APPLICATO');
        
        // Salva l'ordine degli slug API
        $api_slugs = array_column($valid_articles, 'slug');
        update_option('edunews_last_api_slugs', $api_slugs);
        
        // Get existing article IDs
        $existing_posts = get_posts(array(
            'post_type' => 'edunews_article',
            'posts_per_page' => -1,
            'fields' => 'ids'
        ));
        
        $current_article_ids = array();
        
        foreach ($valid_articles as $article) {
            try {
                $preview_id = edunews_create_article_preview($article);
                if ($preview_id) {
                    $current_article_ids[] = $preview_id;
                    #error_log('EduNews: Updated preview for article: ' . $article['title']);
                }
            } catch (Exception $e) {
                #error_log('EduNews: Error processing article ' . $article['title'] . ': ' . $e->getMessage());
                // Continue with next article
            }
        }
        
        // Delete articles that are no longer in the API response
        $articles_to_delete = array_diff($existing_posts, $current_article_ids);
        foreach ($articles_to_delete as $post_id) {
            try {
                wp_delete_post($post_id, true);
                #error_log('EduNews: Deleted old article with ID: ' . $post_id);
            } catch (Exception $e) {
                #error_log('EduNews: Error deleting article ' . $post_id . ': ' . $e->getMessage());
            }
        }
        
        // Update the cache with valid articles (già ordinati per published_at DESC)
        set_transient('edunews_articles_cache', $valid_articles, 15 * MINUTE_IN_SECONDS);
        #error_log('EduNews: Articles cache updated with ' . count($valid_articles) . ' articles (TUTTI). Cache TTL: 15 minutes. Next sync scheduled for: ' . date('Y-m-d H:i:s', wp_next_scheduled('edunews_update_articles_event')));
        
    } catch (Exception $e) {
        #error_log('EduNews: Critical error during update: ' . $e->getMessage());
        throw $e; // Re-throw to be caught by the caller
    } finally {
        // Clear update in progress flag
        delete_transient('edunews_update_in_progress');
    }
}
add_action('edunews_update_articles_event', 'edunews_update_articles');

// Function to update articles without managing the transient (used during activation)
function edunews_update_articles_without_transient() {
    #error_log('EduNews: Starting article update without transient management');
    
    try {
        // Aggiorna la data di ultima sincronizzazione (formato d/m/Y H:i:s)
        update_option('edunews_last_sync', current_time('d/m/Y H:i:s'));
        
        // Elimina la cache per forzare un aggiornamento completo
        delete_transient('edunews_articles_cache');
        delete_transient('edunews_categories_cache');
        delete_transient('edunews_subcategories_cache');
        
        // Rimuovi le categorie numeriche
        edunews_cleanup_numeric_categories();
    
    $response = wp_remote_get('https://edunews24.it/api/articles', array(
        'timeout' => 15,
        'sslverify' => false,
        'headers' => array(
            'Accept' => 'application/json'
        )
    ));
    
    if (is_wp_error($response)) {
        $error_message = $response->get_error_message();
        #error_log('EduNews: API Error during activation update: ' . $error_message);
        throw new Exception('Errore di connessione API: ' . $error_message);
    }
    
    $response_code = wp_remote_retrieve_response_code($response);
    if ($response_code !== 200) {
        $error_message = 'API returned status code: ' . $response_code;
        #error_log('EduNews: ' . $error_message);
        throw new Exception($error_message);
    }

    $body = wp_remote_retrieve_body($response);
    $response_data = json_decode($body, true);
    
    // DEBUG: Log the raw API response structure
    #error_log('EduNews: Raw API response structure: ' . print_r(array_keys($response_data ?: []), true));
    
    // Check if the response has the expected structure
    if (!is_array($response_data)) {
        $error_message = 'Invalid API response format - not an array';
        #error_log('EduNews: ' . $error_message);
        throw new Exception($error_message);
    }
    
    // Handle different API response structures
    $articles = [];
    if (isset($response_data['articles']) && is_array($response_data['articles'])) {
        // New API structure: {"articles": [...]}
        $articles = $response_data['articles'];
        #error_log('EduNews: Using new API structure with articles wrapper');
    } elseif (isset($response_data[0]) && is_array($response_data[0])) {
        // Old API structure: directly an array of articles
        $articles = $response_data;
        #error_log('EduNews: Using old API structure - direct array');
    } else {
        $error_message = 'Invalid API response format - no articles found';
        #error_log('EduNews: ' . $error_message . '. Response keys: ' . print_r(array_keys($response_data), true));
        throw new Exception($error_message);
    }
    
    #error_log('EduNews: Found ' . count($articles) . ' articles during activation update');

    // Validate and process articles
    $valid_articles = [];
    foreach ($articles as $index => $article) {
        // Validate required fields and add missing ones
        if (!isset($article['title']) || empty($article['title'])) {
            #error_log('EduNews: Skipping article at index ' . $index . ' - missing title');
            continue;
        }
        
        // Generate missing slug if not present
        if (!isset($article['slug']) || empty($article['slug'])) {
            $article['slug'] = sanitize_title($article['title']) . '-' . ($index + 1); // Use title+index as fallback slug
            #error_log('EduNews: Generated slug ' . $article['slug'] . ' for article: ' . $article['title']);
        }
        
        // Ensure required fields have default values (slug già gestito sopra)
        $article['category_slug'] = $article['category_slug'] ?? 'general';
        $article['published_at'] = $article['published_at'] ?? current_time('Y-m-d\TH:i:s.uP');
        $article['excerpt'] = $article['excerpt'] ?? '';
        $article['category'] = $article['category'] ?? 'Generale';
        $article['image_url'] = $article['image_url'] ?? '';
        
        $valid_articles[] = $article;
    }
    
    if (empty($valid_articles)) {
        $error_message = 'No valid articles found in API response';
        #error_log('EduNews: ' . $error_message);
        throw new Exception($error_message);
    }

    // IMPORTANTE: Ordina gli articoli per published_at DESC (più recenti prima)
    usort($valid_articles, function($a, $b) {
        $time_a = strtotime($a['published_at']);
        $time_b = strtotime($b['published_at']);
        return $time_b - $time_a; // DESC: più recenti prima
    });
    
    #error_log('EduNews: Ordinati ' . count($valid_articles) . ' articoli per data di pubblicazione (più recenti prima) - NESSUN LIMITE APPLICATO');
    
    // Salva l'ordine degli slug API
    $api_slugs = array_column($valid_articles, 'slug');
    update_option('edunews_last_api_slugs', $api_slugs);
    
    // Get existing article IDs
    $existing_posts = get_posts(array(
        'post_type' => 'edunews_article',
        'posts_per_page' => -1,
        'fields' => 'ids'
    ));
    
    $current_article_ids = array();
    
    foreach ($valid_articles as $article) {
        try {
            $preview_id = edunews_create_article_preview($article);
            if ($preview_id) {
                $current_article_ids[] = $preview_id;
                #error_log('EduNews: Updated preview for article: ' . $article['title']);
            }
        } catch (Exception $e) {
            #error_log('EduNews: Error processing article ' . $article['title'] . ': ' . $e->getMessage());
            // Continue with next article
        }
    }
    
    // Delete articles that are no longer in the API response
    $articles_to_delete = array_diff($existing_posts, $current_article_ids);
    foreach ($articles_to_delete as $post_id) {
        try {
            wp_delete_post($post_id, true);
            #error_log('EduNews: Deleted old article with ID: ' . $post_id);
        } catch (Exception $e) {
            #error_log('EduNews: Error deleting article ' . $post_id . ': ' . $e->getMessage());
        }
    }
    
    // Update the cache with valid articles (già ordinati per published_at DESC)
    set_transient('edunews_articles_cache', $valid_articles, 15 * MINUTE_IN_SECONDS);
    #error_log('EduNews: Articles cache updated with ' . count($valid_articles) . ' articles during activation. Cache TTL: 15 minutes.');
    
    } catch (Exception $e) {
        #error_log('EduNews: Error during manual sync: ' . $e->getMessage());
        error_log('EduNews: Critical error in edunews_update_articles_without_transient(): ' . $e->getMessage());
        throw $e; // Re-lancia l'eccezione per il chiamante
    }
}

// Function to create/update EduNews article preview
function edunews_create_article_preview($article_data) {
    // Validate input data
    if (!is_array($article_data)) {
        #error_log('EduNews: Invalid article data - not an array');
        return false;
    }
    
    // Check for required fields
    if (!isset($article_data['title']) || empty($article_data['title'])) {
        #error_log('EduNews: Missing required field: title');
        return false;
    }
    
    if (!isset($article_data['slug']) || empty($article_data['slug'])) {
        #error_log('EduNews: Missing required field: slug');
        return false;
    }
    
    #error_log('EduNews: Creating article preview for: ' . $article_data['title']);
    
    // Check if article already exists
    $existing_post = get_posts(array(
        'post_type' => 'edunews_article',
        'meta_key' => '_edunews_original_slug',
        'meta_value' => $article_data['slug'],
        'posts_per_page' => 1
    ));

    if (!empty($existing_post)) {
        #error_log('EduNews: Article already exists, updating: ' . $existing_post[0]->ID);
        $post_id = $existing_post[0]->ID;
    } else {
        #error_log('EduNews: Creating new article preview');
        // Usa summary se disponibile, altrimenti usa excerpt come fallback
        $content_to_use = !empty($article_data['summary']) ? $article_data['summary'] : (!empty($article_data['excerpt']) ? $article_data['excerpt'] : '');
        // Usa title_summary se disponibile, altrimenti usa title
        $title_to_use = !empty($article_data['title_summary']) ? $article_data['title_summary'] : $article_data['title'];
        $post_args = array(
            'post_title'   => $title_to_use,
            'post_content' => $content_to_use, 
            'post_excerpt' => $content_to_use, 
            'post_status'  => 'publish',
            'post_type'    => 'edunews_article'
        );
        $post_id = wp_insert_post($post_args);
        
        // Se stiamo aggiornando un post esistente, dobbiamo usare wp_update_post
        // La logica precedente gestiva questo solo per i meta, non per il contenuto.
        // Dobbiamo assicurarci che anche l'update aggiorni content ed excerpt.
        // Tuttavia, la struttura attuale chiama wp_insert_post solo per i *nuovi* post.
        // Per gli esistenti ($existing_post), usa solo update_post_meta.
        // Aggiungiamo un wp_update_post qui per coerenza:
        if (!empty($existing_post)) {
             // Usa summary se disponibile, altrimenti usa excerpt come fallback
             $content_to_use = !empty($article_data['summary']) ? $article_data['summary'] : (!empty($article_data['excerpt']) ? $article_data['excerpt'] : '');
             // Usa title_summary se disponibile, altrimenti usa title
             $title_to_use = !empty($article_data['title_summary']) ? $article_data['title_summary'] : $article_data['title'];
             $update_args = array(
                'ID'           => $post_id, // $post_id è l'ID del post esistente in questo blocco
                'post_title'   => $title_to_use,
                'post_content' => $content_to_use,
                'post_excerpt' => $content_to_use,
             );
             wp_update_post($update_args);
             #error_log('EduNews: Updated post content/excerpt for existing post: ' . $post_id);
        }
    }

    if (!is_wp_error($post_id)) {
        // Save original article slug and URL - con controlli di sicurezza
        update_post_meta($post_id, '_edunews_original_slug', $article_data['slug']);
        
        // Costruisci URL solo se abbiamo i campi necessari
        if (isset($article_data['category_slug']) && isset($article_data['slug'])) {
            $original_url = 'https://edunews24.it/' . $article_data['category_slug'] . '/' . $article_data['slug'];
            update_post_meta($post_id, '_edunews_original_url', $original_url);
        } else {
            #error_log('EduNews: Warning - missing category_slug or slug for article slug: ' . $article_data['slug']);
        }
        
        if (isset($article_data['published_at'])) {
            update_post_meta($post_id, '_edunews_published_at', $article_data['published_at']);
        }
        
        update_post_meta($post_id, '_edunews_api_slug', $article_data['slug']);
        
        // Save keywords if available
        if (isset($article_data['keywords']) && !empty($article_data['keywords'])) {
            // Assicurati che le keywords vengano salvate come stringa
            $keywords = $article_data['keywords'];
            if (is_array($keywords)) {
                $keywords = implode(', ', $keywords);
            }
            update_post_meta($post_id, '_edunews_keywords', $keywords);
            #error_log('EduNews: Keywords saved for article: ' . $post_id);
        } elseif (isset($article_data['tags']) && !empty($article_data['tags'])) {
            // Use tags as fallback for keywords
            $tags = $article_data['tags'];
            if (is_array($tags)) {
                $tags = implode(', ', $tags);
            }
            update_post_meta($post_id, '_edunews_keywords', $tags);
            #error_log('EduNews: Tags used as keywords for article: ' . $post_id);
        }
        
        // Save image URL if available
        if (isset($article_data['image_url']) && !empty($article_data['image_url'])) {
            update_post_meta($post_id, '_edunews_image_url', $article_data['image_url']);
            #error_log('EduNews: Image URL saved for article: ' . $post_id);
        }
        
        // Set category by name (string), not by ID (integer)
        if (isset($article_data['category']) && !empty($article_data['category'])) {
            // Use the category value directly, trimming whitespace
            $category_value = trim($article_data['category']); 
            
            // Ensure category value is not empty after trimming
            if (!empty($category_value)) {
                // --- PATCH: blocca qualsiasi valore numerico o non stringa ---
                if (!is_string($category_value) || is_numeric($category_value)) {
                    #error_log('EduNews: [PATCH] Received invalid or numeric category value (' . print_r($category_value, true) . ') for article slug ' . $article_data['slug'] . ' (Post ID: ' . $post_id . '). Skipping category assignment.');
                } else {
                    // Usa solo il nome della categoria (mai ID)
                    $category_name = $category_value;
                    $taxonomy = 'edunews_category'; 
                    // (Opzionale) Assicurati che la categoria esista, altrimenti la crea
                    $term_exists_result = term_exists($category_name, $taxonomy);
                    if (!$term_exists_result || is_wp_error($term_exists_result)) {
                        $insert_result = wp_insert_term($category_name, $taxonomy);
                        if (is_wp_error($insert_result)) {
                            #error_log('EduNews: [PATCH] wp_insert_term FAILED for name ' . $category_name . '. Error: ' . $insert_result->get_error_message());
                        }
                    }
                    // Assegna la categoria SOLO tramite nome
                    #error_log('EduNews: [PATCH] Assigning category by NAME: ' . $category_name . ' to post ID: ' . $post_id);
                    wp_set_object_terms($post_id, array($category_name), $taxonomy, false);
                }
            } else {
                #error_log('EduNews: [PATCH] Empty category name received for article ID (related to post): ' . $post_id);
            }
        }
        
        // Gestione delle sottocategorie (secondary_category_slugs)
        // Le sottocategorie sono ora termini figli nella tassonomia edunews_category
        if (isset($article_data['secondary_category_slugs']) && !empty($article_data['secondary_category_slugs']) && is_array($article_data['secondary_category_slugs'])) {
            $subcategory_ids = [];
            
            // Ottieni l'ID della categoria principale per usarlo come parent
            $parent_category_id = null;
            if (!empty($category_name)) {
                $parent_term = get_term_by('name', $category_name, 'edunews_category');
                if ($parent_term && !is_wp_error($parent_term)) {
                    $parent_category_id = $parent_term->term_id;
                }
            }
            
            foreach ($article_data['secondary_category_slugs'] as $subcategory_slug) {
                if (!empty($subcategory_slug) && is_string($subcategory_slug)) {
                    // Trasforma lo slug in un nome leggibile (capitalize prima lettera)
                    $subcategory_name = ucfirst(str_replace('-', ' ', $subcategory_slug));
                    
                    // Verifica se la sottocategoria esiste come figlio della categoria principale
                    $subcategory_exists = term_exists($subcategory_name, 'edunews_category');
                    if (!$subcategory_exists || is_wp_error($subcategory_exists)) {
                        // Crea la sottocategoria come figlio della categoria principale
                        $insert_args = array(
                            'slug' => $subcategory_slug
                        );
                        
                        // Se abbiamo un parent ID valido, lo impostiamo
                        if ($parent_category_id) {
                            $insert_args['parent'] = $parent_category_id;
                        }
                        
                        $insert_result = wp_insert_term($subcategory_name, 'edunews_category', $insert_args);
                        if (is_wp_error($insert_result)) {
                            #error_log('EduNews: Errore nella creazione della sottocategoria ' . $subcategory_name . ': ' . $insert_result->get_error_message());
                            continue; // Continua con la prossima sottocategoria
                        }
                        #error_log('EduNews: Creata nuova sottocategoria: ' . $subcategory_name . ' (slug: ' . $subcategory_slug . ', parent: ' . $parent_category_id . ')');
                        $subcategory_ids[] = $insert_result['term_id'];
                    } else {
                        // Se esiste, aggiungiamo il suo ID
                        $existing_term = get_term_by('name', $subcategory_name, 'edunews_category');
                        if ($existing_term && !is_wp_error($existing_term)) {
                            $subcategory_ids[] = $existing_term->term_id;
                        }
                    }
                }
            }
            
            // Assegna le sottocategorie all'articolo usando la tassonomia edunews_category
            if (!empty($subcategory_ids)) {
                #error_log('EduNews: Assegnazione sottocategorie a post ID ' . $post_id . ': IDs ' . implode(', ', $subcategory_ids));
                
                // Ottieni gli ID delle categorie attuali per mantenerle
                $current_category_ids = wp_get_object_terms($post_id, 'edunews_category', array('fields' => 'ids'));
                if (!is_wp_error($current_category_ids)) {
                    $all_category_ids = array_merge($current_category_ids, $subcategory_ids);
                    $all_category_ids = array_unique($all_category_ids);
                    wp_set_object_terms($post_id, $all_category_ids, 'edunews_category', false);
                } else {
                    wp_set_object_terms($post_id, $subcategory_ids, 'edunews_category', true);
                }
            }
        }
        
        #error_log('EduNews: Article preview created/updated successfully: ' . $post_id);
        return $post_id;
    }
    
    #error_log('EduNews: Error creating article preview: ' . $post_id->get_error_message());
    return false;
}

// Modify the shortcode to use local previews
function edunews_articles_shortcode($atts) {
    // Verifichiamo prima se max_posts è stato esplicitamente passato
    $max_posts_specified = isset($atts['max_posts']);
    
    // Default attributes
    $atts = shortcode_atts(array(
        'max_posts' => 1100,           // Valore predefinito alto per mostrare tutti
        'display_mode' => 'grid',      // grid, list, or slide
        'categories' => '',            // Comma-separated category slugs
        'subcategories' => '',         // Comma-separated subcategory slugs
        'title' => ''                  // Optional title for the section
    ), $atts, 'edunews_articles');

    // Sanitize attributes
    $max_posts = intval($atts['max_posts']);
    // Se max_posts è 0, impostiamo un valore elevato per mostrare tutti gli articoli
    if ($max_posts === 0) {
        $max_posts = 1100;
    }
    
    // Limitiamo a massimo 50 articoli quando il display mode è 'slide'
    $display_mode = sanitize_key($atts['display_mode']);
    if ($display_mode === 'slide' && $max_posts > 50) {
        $max_posts = 50;
    }
    
    $categories = array_map('sanitize_key', explode(',', $atts['categories']));
    $categories = array_filter($categories); // Remove empty entries
    $subcategories = array_map('sanitize_key', explode(',', $atts['subcategories']));
    $subcategories = array_filter($subcategories); // Remove empty entries
    $title = sanitize_text_field($atts['title']);

    // Query arguments
    $args = array(
        'post_type' => 'edunews_article',
        'post_status' => 'publish',
        'posts_per_page' => ($max_posts >= 1000) ? -1 : $max_posts, // -1 significa "tutti i post" in WordPress
        'meta_key' => '_edunews_published_at',
        'orderby' => 'meta_value',
        'order' => 'DESC',
        'meta_type' => 'DATETIME'
    );

    // Aggiungi il filtro per categoria e sottocategoria se specificato
    $tax_query = array();
    
    if (!empty($categories)) {
        $tax_query[] = array(
            'taxonomy' => 'edunews_category',
            'field' => 'slug',
            'terms' => $categories
        );
    }
    
    if (!empty($subcategories)) {
        $tax_query[] = array(
            'taxonomy' => 'edunews_category',
            'field' => 'slug',
            'terms' => $subcategories
        );
    }
    
    // Se abbiamo sia categorie che sottocategorie, usiamo l'operatore AND
    if (!empty($tax_query)) {
        if (count($tax_query) > 1) {
            $tax_query['relation'] = 'AND';
        }
        $args['tax_query'] = $tax_query;
    }

    // Esegui la query
    $query = new WP_Query($args);
    $articles = array();

    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            // Ottieni i metadati dell'articolo
            $original_url = get_post_meta(get_the_ID(), '_edunews_original_url', true);
            $image_url = get_post_meta(get_the_ID(), '_edunews_image_url', true);
            $published_at = get_post_meta(get_the_ID(), '_edunews_published_at', true);
            
            // Ottieni tutte le categorie (principali e sottocategorie)
            $terms = get_the_terms(get_the_ID(), 'edunews_category');
            $category = '';
            $category_slug = '';
            $subcategories = [];
            
            if (!empty($terms) && !is_wp_error($terms)) {
                // Separa categorie principali (parent = 0) da sottocategorie (parent > 0)
                $main_category = null;
                $sub_categories = [];
                
                foreach ($terms as $term) {
                    if ($term->parent == 0) {
                        // Categoria principale
                        if (!$main_category) {
                            $main_category = $term;
                        }
                    } else {
                        // Sottocategoria
                        $sub_categories[] = $term;
                    }
                }
                
                // Imposta la categoria principale
                if ($main_category) {
                    $category = $main_category->name;
                    $category_slug = $main_category->slug;
                }
                
                // Imposta le sottocategorie
                foreach ($sub_categories as $subcat) {
                    $subcategories[] = array(
                        'name' => $subcat->name,
                        'slug' => $subcat->slug
                    );
                }
            }
            
            $articles[] = array(
                'id' => get_the_ID(),
                'title' => get_the_title(),
                'content' => get_the_content(),
                'excerpt' => get_the_excerpt(),
                'url' => get_permalink(),
                'original_url' => $original_url,
                'image_url' => $image_url,
                'published_at' => $published_at ? $published_at : get_the_date('Y-m-d H:i:s'),
                'category' => $category,
                'category_slug' => $category_slug,
                'subcategories' => $subcategories
            );
        }
        wp_reset_postdata();
    }

    ob_start();

    // Output the title if provided
    if (!empty($title)) {
        echo '<h2 class="edunews-title">' . esc_html($title) . '</h2>';
    }

    // Load the appropriate template
    $template_path = plugin_dir_path(__FILE__) . 'templates/' . $display_mode . '.php';
    if (file_exists($template_path)) {
        // Pass variables to the template
        include $template_path;
    } else {
        echo '<p>Errore: Template non trovato (' . esc_html($display_mode) . ').</p>';
    }

    return ob_get_clean();
}
add_shortcode('edunews_articles', 'edunews_articles_shortcode');

// Helper function to add debug logging for API responses
function edunews_debug_log($message, $data = null) {
    if (defined('WP_DEBUG') && WP_DEBUG) {
        if ($data !== null) {
            error_log('EduNews DEBUG: ' . $message . ' - Data: ' . print_r($data, true));
        } else {
            error_log('EduNews DEBUG: ' . $message);
        }
    }
}

// Function to test and debug sync functionality
function edunews_test_sync_debug() {
    if (!current_user_can('manage_options')) {
        wp_die('Unauthorized');
    }
    
    // Verifica il nonce per sicurezza
    if (!isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'edunews_debug_sync')) {
        wp_die('Verifica di sicurezza fallita');
    }
    
    #error_log('=== EduNews DEBUG SYNC TEST START ===');
    
    // Informazioni sullo stato del cron
    $hook = 'edunews_update_articles_event';
    $next_scheduled = wp_next_scheduled($hook);
    $current_time = time();
    
    #error_log('EduNews DEBUG: Ora corrente: ' . date('Y-m-d H:i:s', $current_time));
    #error_log('EduNews DEBUG: Prossima sync programmata: ' . ($next_scheduled ? date('Y-m-d H:i:s', $next_scheduled) : 'NON PROGRAMMATA'));
    #error_log('EduNews DEBUG: Minuti fino alla prossima sync: ' . ($next_scheduled ? round(($next_scheduled - $current_time) / 60, 2) : 'N/A'));
    #error_log('EduNews DEBUG: Intervallo configurato: 20 minuti (every 20 minutes)');
    
    // Verifica l'intervallo corrente
    $current_schedule = wp_get_schedule($hook);
    #error_log('EduNews DEBUG: Intervallo attuale: ' . ($current_schedule ? $current_schedule : 'NON IMPOSTATO'));
    if ($current_schedule !== 'twenty_minutes') {
        #error_log('EduNews DEBUG: PROBLEMA - Intervallo errato! Dovrebbe essere "twenty_minutes" ma è "' . $current_schedule . '"');
    }
    
    // Verifica se WP-CRON è disabilitato
    if (defined('DISABLE_WP_CRON') && DISABLE_WP_CRON) {
        #error_log('EduNews DEBUG: PROBLEMA - WP-CRON è DISABILITATO');
    } else {
        #error_log('EduNews DEBUG: WP-CRON è abilitato');
    }
    
    // Verifica se c'è una sincronizzazione in corso
    $sync_in_progress = get_transient('edunews_update_in_progress');
    #error_log('EduNews DEBUG: Sincronizzazione in corso: ' . ($sync_in_progress ? 'SÌ' : 'NO'));
    
    // Ultima sincronizzazione
    $last_sync = get_option('edunews_last_sync', 'Mai');
    #error_log('EduNews DEBUG: Ultima sincronizzazione: ' . $last_sync);
    
    // Verifica cache
    $cached_data = get_transient('edunews_articles_cache');
    $cache_count = $cached_data ? count($cached_data) : 0;
    #error_log('EduNews DEBUG: Articoli in cache: ' . $cache_count);
    
    // Conta articoli nel database
    $db_articles = get_posts(array(
        'post_type' => 'edunews_article',
        'posts_per_page' => -1,
        'fields' => 'ids'
    ));
    #error_log('EduNews DEBUG: Articoli nel database: ' . count($db_articles));
    
    #error_log('=== EduNews DEBUG SYNC TEST END ===');
    
    // Redirect con messaggio
    wp_redirect(add_query_arg('edunews_debug', '1', admin_url('admin.php?page=edunews-shortcode')));
    exit;
}

// Add handler for debug test
add_action('admin_init', function() {
    if (isset($_GET['edunews_debug_sync'])) {
        edunews_test_sync_debug();
    }
});

// Add debug notice
add_action('admin_notices', function() {
    if (isset($_GET['edunews_debug'])) {
        ?>
        <div class="notice notice-info is-dismissible">
            <p>Debug della sincronizzazione completato. Controlla i log di debug per i dettagli.</p>
        </div>
        <?php
    }
});

// Function to force sync articles manually with complete cleanup
function edunews_force_sync() {
    if (!current_user_can('manage_options')) {
        wp_die('Unauthorized');
    }
    
    edunews_debug_log('Force sync with cleanup initiated by user (non-AJAX)');
    
    try {
        // Set sync in progress flag for the entire process
        set_transient('edunews_update_in_progress', true, 120); // 2 minutes timeout for easier debugging
        
        // Step 1: Complete cleanup (like during activation)
        edunews_debug_log('Force sync: Starting complete cleanup...');
        
        // Auto-cleanup articles
        edunews_auto_cleanup_articles();
        
        // Cleanup numeric categories and old taxonomy
        edunews_cleanup_numeric_categories();
        edunews_cleanup_old_subcategory_taxonomy();
        
        edunews_debug_log('Force sync: Cleanup completed, starting sync...');
        
        // Step 2: Sync articles (using the version without transient management since we already set it)
        edunews_update_articles_without_transient();
        
        edunews_debug_log('Force sync: Complete process finished successfully');
        
        // Set success message
        set_transient('edunews_admin_notice', array(
            'type' => 'success',
            'message' => 'Cleanup e sincronizzazione completati con successo!'
        ), 30);
        
    } catch (Exception $e) {
        // Set error message
        set_transient('edunews_admin_notice', array(
            'type' => 'error',
            'message' => 'Errore durante il cleanup e sincronizzazione: ' . $e->getMessage()
        ), 30);
        
        edunews_debug_log('Force sync with cleanup failed', $e->getMessage());
    } finally {
        // Always clear the sync flag when done
        delete_transient('edunews_update_in_progress');
        edunews_debug_log('Force sync: Removed sync in progress flag');
    }
    
    // Redirect back to admin page
    wp_redirect(admin_url('admin.php?page=edunews-shortcode'));
    exit;
}

// Add AJAX handler for forced sync (for compatibility)
add_action('wp_ajax_edunews_force_sync', 'edunews_ajax_force_sync');
function edunews_ajax_force_sync() {
    check_ajax_referer('edunews_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Permessi insufficienti']);
        return;
    }
    
    // Check if update is already in progress
    if (get_transient('edunews_update_in_progress')) {
        wp_send_json_error(['message' => 'Sincronizzazione già in corso']);
        return;
    }
    
    edunews_debug_log('AJAX force sync with cleanup initiated by user');
    
    try {
        // Set sync in progress flag for the entire process
        set_transient('edunews_update_in_progress', true, 120); // 2 minutes timeout for easier debugging
        edunews_debug_log('Force sync: Set transient edunews_update_in_progress = true');
        
        // Step 1: Complete cleanup (like during activation)
        edunews_debug_log('Force sync: Starting complete cleanup...');
        
        // Auto-cleanup articles
        edunews_auto_cleanup_articles();
        
        // Cleanup numeric categories and old taxonomy
        edunews_cleanup_numeric_categories();
        edunews_cleanup_old_subcategory_taxonomy();
        
        edunews_debug_log('Force sync: Cleanup completed, starting sync...');
        
        // Step 2: Sync articles (using the version without transient management since we already set it)
        edunews_debug_log('Force sync: About to call edunews_update_articles_without_transient()...');
        edunews_update_articles_without_transient();
        edunews_debug_log('Force sync: edunews_update_articles_without_transient() completed without exceptions');
        
        edunews_debug_log('Force sync: Complete process finished successfully');
        
        wp_send_json_success([
            'message' => 'Cleanup e sincronizzazione completati',
            'last_sync' => get_option('edunews_last_sync', 'Mai')
        ]);
        
    } catch (Exception $e) {
        edunews_debug_log('AJAX force sync with cleanup failed', $e->getMessage());
        wp_send_json_error([
            'message' => 'Errore durante il cleanup e sincronizzazione: ' . $e->getMessage()
        ]);
    } finally {
        // Always clear the sync flag when done
        edunews_debug_log('Force sync: Entering finally block...');
        delete_transient('edunews_update_in_progress');
        edunews_debug_log('Force sync: Removed sync in progress flag');
        
        // Verify transient is actually cleared
        $transient_check = get_transient('edunews_update_in_progress');
        edunews_debug_log('Force sync: Transient check after delete: ' . ($transient_check ? 'STILL EXISTS' : 'CLEARED'));
    }
}

// Add bulk delete action handler
add_action('admin_init', 'edunews_handle_bulk_delete');
add_action('admin_init', 'edunews_remove_metaboxes');

// Funzione per rimuovere tutte le metaboxes dagli articoli edunews
function edunews_remove_metaboxes() {
    // Rimuovi tutte le metaboxes per edunews_article
    remove_meta_box('submitdiv', 'edunews_article', 'side'); // Rimuove "Pubblica"
    remove_meta_box('postcustom', 'edunews_article', 'normal'); // Rimuove "Custom Fields"
    remove_meta_box('slugdiv', 'edunews_article', 'normal'); // Rimuove "Slug"
    remove_meta_box('authordiv', 'edunews_article', 'normal'); // Rimuove "Autore"
    remove_meta_box('commentstatusdiv', 'edunews_article', 'normal'); // Rimuove "Discussione"
    remove_meta_box('commentsdiv', 'edunews_article', 'normal'); // Rimuove "Commenti"
    remove_meta_box('revisionsdiv', 'edunews_article', 'normal'); // Rimuove "Revisioni"
    remove_meta_box('categorydiv', 'edunews_article', 'side'); // Rimuove "Categorie"
    remove_meta_box('tagsdiv-post_tag', 'edunews_article', 'side'); // Rimuove "Tags"
    
    // Rimuovi le metabox specifiche della custom taxonomy
    remove_meta_box('edunews_categorydiv', 'edunews_article', 'side');
    
    // Disabilita l'editor di Gutenberg
    add_filter('use_block_editor_for_post_type', function($use_block_editor, $post_type) {
        if ($post_type === 'edunews_article') {
            return false;
        }
        return $use_block_editor;
    }, 10, 2);
}

// Reindirizza gli utenti dalla pagina di edit alla pagina di visualizzazione
add_action('admin_init', 'edunews_redirect_from_edit');
function edunews_redirect_from_edit() {
    global $pagenow;
    
    // Controlla se siamo nella pagina di modifica di un post
    if ($pagenow == 'post.php' && isset($_GET['action']) && $_GET['action'] == 'edit') {
        // Verifica se è un articolo edunews
        if (isset($_GET['post'])) {
            $post_id = intval($_GET['post']);
            $post_type = get_post_type($post_id);
            
            if ($post_type === 'edunews_article') {
                // Reindirizza alla pagina di visualizzazione
                $view_url = get_permalink($post_id);
                wp_redirect($view_url);
                exit;
            }
        }
    }
}

// Rimuovi opzione di Quick Edit per edunews_article
add_filter('post_row_actions', 'edunews_remove_quick_edit', 10, 2);
function edunews_remove_quick_edit($actions, $post) {
    if ($post->post_type === 'edunews_article') {
        // Rimuovi azioni di modifica
        unset($actions['edit']);
        unset($actions['inline hide-if-no-js']); // Quick Edit
        unset($actions['trash']);
        unset($actions['delete']);
    }
    return $actions;
}

// Rimuovi le azioni di modifica di gruppo per gli articoli EduNews
add_filter('bulk_actions-edit-edunews_article', 'edunews_remove_bulk_actions');
function edunews_remove_bulk_actions($bulk_actions) {
    // Rimuovi l'azione di modifica di gruppo
    unset($bulk_actions['edit']);
    return $bulk_actions;
}

// Sostituisci il form di modifica con un messaggio
add_action('edit_form_top', 'edunews_disable_edit_form');
function edunews_disable_edit_form($post) {
    if ($post->post_type === 'edunews_article') {
        // Interrompi il rendering del form
        ?>
        <style>
            #post, #postdivrich, #postbox-container-1, #postbox-container-2 {
                display: none !important;
            }
        </style>
        <div class="notice notice-error">
            <p><strong>Modifica non consentita:</strong> Questo è un articolo importato automaticamente da EduNews24. Non può essere modificato manualmente.</p>
            <p><a href="<?php echo esc_url(admin_url('edit.php?post_type=edunews_article')); ?>" class="button">Torna alla lista</a></p>
        </div>
        <?php
    }
}

function edunews_handle_bulk_delete() {
    if (isset($_GET['edunews_bulk_delete']) && isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'edunews_bulk_delete')) {
        if (!current_user_can('manage_options')) {
            wp_die('Non hai i permessi necessari per eseguire questa azione.');
        }

        // Get all EduNews articles
        $articles = get_posts(array(
            'post_type' => 'edunews_article',
            'posts_per_page' => -1,
            'fields' => 'ids'
        ));

        // Delete each article
        foreach ($articles as $article_id) {
            wp_delete_post($article_id, true);
        }

        // Clear the cache
        delete_transient('edunews_articles_cache');
        delete_transient('edunews_categories_cache');
        delete_transient('edunews_subcategories_cache');

        // Redirect back with success message
        wp_redirect(add_query_arg('edunews_deleted', '1', admin_url('edit.php?post_type=edunews_article')));
        exit;
    }
}

// Add admin notice for bulk delete
add_action('admin_notices', 'edunews_bulk_delete_notice');
function edunews_bulk_delete_notice() {
    if (isset($_GET['edunews_deleted'])) {
        ?>
        <div class="notice notice-success is-dismissible">
            <p>Tutti gli articoli EduNews sono stati eliminati con successo.</p>
        </div>
        <?php
    }
}

// Add admin notice for sync in progress
add_action('admin_notices', 'edunews_sync_in_progress_notice');
function edunews_sync_in_progress_notice() {
    global $pagenow, $post_type;
    
    // Show only on the EduNews articles admin page
    if ($pagenow === 'edit.php' && $post_type === 'edunews_article') {
        $is_syncing = get_transient('edunews_update_in_progress');
        ?>
        <div id="edunews-sync-notice" class="notice notice-error" style="<?php echo $is_syncing ? '' : 'display: none;'; ?>">
            <p><strong>🔄 Sincronizzazione in corso...</strong> Gli articoli potrebbero non essere aggiornati. La sincronizzazione è in corso, attendere il completamento.</p>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // Check sync status every 5 seconds on articles page
            function checkSyncStatus() {
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'edunews_check_sync_status_simple',
                        nonce: '<?php echo wp_create_nonce('edunews_admin_nonce'); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            const syncNotice = $('#edunews-sync-notice');
                            if (response.data.is_syncing) {
                                syncNotice.show();
                            } else {
                                syncNotice.hide();
                            }
                        }
                    },
                    error: function() {
                        console.log('Errore nel controllo dello stato di sincronizzazione');
                    }
                });
            }
            
            // Check immediately and then every 5 seconds
            checkSyncStatus();
            setInterval(checkSyncStatus, 5000);
        });
        </script>
        <?php
    }
}

// Add simple AJAX handler for sync status check (without nonce verification issues)
add_action('wp_ajax_edunews_check_sync_status_simple', 'edunews_ajax_check_sync_status_simple');
function edunews_ajax_check_sync_status_simple() {
    // Simple check without complex nonce verification for this use case
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Permessi insufficienti']);
        return;
    }
    
    $is_syncing = get_transient('edunews_update_in_progress');
    
    wp_send_json_success([
        'is_syncing' => (bool)$is_syncing
    ]);
}

// Add debug function to manually clear sync transient
add_action('wp_ajax_edunews_clear_sync_transient', 'edunews_ajax_clear_sync_transient');
function edunews_ajax_clear_sync_transient() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Permessi insufficienti']);
        return;
    }
    
    $was_active = get_transient('edunews_update_in_progress');
    delete_transient('edunews_update_in_progress');
    
    edunews_debug_log('Manual sync transient clear - was active: ' . ($was_active ? 'YES' : 'NO'));
    
    wp_send_json_success([
        'message' => 'Transient di sincronizzazione rimosso',
        'was_active' => (bool)$was_active
    ]);
}

// Add bulk delete button to admin page
function edunews_add_bulk_delete_button_header() {
    global $post_type, $pagenow;
    
    // Solo nella pagina edit.php per edunews_article
    if ($pagenow === 'edit.php' && $post_type === 'edunews_article') {
        ?>
        <div style="margin: 10px 0; padding: 10px; background: #f1f1f1; border-left: 4px solid #dc3232;">
            <strong>Strumenti Debug:</strong>
            <a href="<?php echo wp_nonce_url(admin_url('edit.php?post_type=edunews_article&edunews_bulk_delete=1'), 'edunews_bulk_delete'); ?>" 
               class="button" 
               onclick="return confirm('Sei sicuro di voler eliminare tutti gli articoli EduNews? Questa azione non può essere annullata.');"
               style="background: #dc3232; border-color: #dc3232; color: white; margin-left: 10px;">
                🗑️ Svuota Tutti gli Articoli
            </a>
            <span style="margin-left: 10px; color: #666;">Elimina tutti gli articoli per test e debug</span>
        </div>
        <?php
    }
}

function edunews_add_bulk_delete_button() {
    global $post_type;
    if ($post_type === 'edunews_article') {
        ?>
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                // Crea il bottone di svuotamento
                var deleteButton = '<a href="<?php echo wp_nonce_url(admin_url('edit.php?post_type=edunews_article&edunews_bulk_delete=1'), 'edunews_bulk_delete'); ?>" class="page-title-action" onclick="return confirm(\'Sei sicuro di voler eliminare tutti gli articoli EduNews? Questa azione non può essere annullata.\');" style="background: #dc3232; border-color: #dc3232; color: white; margin-left: 10px; display: inline-block;">🗑️ Svuota articoli</a>';
                
                // Prova diversi punti di inserimento
                if ($('.wrap h1').length > 0) {
                    // Aggiungi dopo il titolo h1
                    $('.wrap h1').after(deleteButton);
                } else if ($('.wrap .wp-heading-inline').length > 0) {
                    // Fallback: dopo il titolo con classe wp-heading-inline
                    $('.wrap .wp-heading-inline').after(deleteButton);
                } else if ($('.wrap').length > 0) {
                    // Ultimo fallback: all'inizio del wrap
                    $('.wrap').prepend('<div style="margin: 10px 0;">' + deleteButton + '</div>');
                }
            });
        </script>
        <?php
    }
}

function edunews_cleanup_numeric_categories() {
    #error_log('EduNews: Pulizia delle categorie numeriche in corso');
    
    // Recupera tutte le categorie
    $categories = get_terms(array(
        'taxonomy' => 'edunews_category',
        'hide_empty' => false,
    ));
    
    if (is_wp_error($categories)) {
        #error_log('EduNews: Errore nel recupero delle categorie: ' . $categories->get_error_message());
    } else {
        $deleted_count = 0;
        foreach ($categories as $category) {
            // Rimuovi categorie con nomi puramente numerici o che iniziano con 'Categoria '
            if (is_numeric($category->name) || strpos($category->name, 'Categoria ') === 0) {
                $result = wp_delete_term($category->term_id, 'edunews_category');
                if (!is_wp_error($result)) {
                    #error_log('EduNews: Eliminata categoria: ' . $category->name);
                    $deleted_count++;
                } else {
                    #error_log('EduNews: Errore nell\'eliminazione della categoria ' . $category->name . ': ' . $result->get_error_message());
                }
            }
        }
        #error_log('EduNews: Pulizia categorie completata. Eliminate ' . $deleted_count . ' categorie');
    }
    
    // Le sottocategorie sono ora nella stessa tassonomia edunews_category, quindi non serve recuperarle separatamente
}

// Funzione per ordinare gli articoli nella bacheca admin e nelle pagine della tassonomia per data di pubblicazione
function edunews_admin_sort_by_api_id($query) {
    // Non modificare query in admin se non è la query principale o non è il post type giusto
    if (is_admin() && (!$query->is_main_query() || $query->get('post_type') !== 'edunews_article')) {
        return;
    }
    
    // Non modificare query pubbliche se non è la query principale o non è una pagina della tassonomia edunews_category
    if (!is_admin() && (!$query->is_main_query() || !is_tax('edunews_category'))) {
        return;
    }

    // Forza l'ordinamento per published_at - più recenti prima
    $query->set('orderby', 'meta_value');
    $query->set('meta_key', '_edunews_published_at');
    $query->set('order', 'DESC');
    $query->set('meta_type', 'DATETIME');
    
    // Non limitiamo più i posts per page qui, lasciamo che WordPress gestisca la paginazione normalmente
    // $query->set('posts_per_page', -1);
}
add_action('pre_get_posts', 'edunews_admin_sort_by_api_id');



// SEO Enhancements

/**
 * Adds SEO meta tags (description, Open Graph, Twitter Cards) to the head of single edunews_article pages.
 */
function edunews_add_seo_meta_tags() {
    if (is_singular('edunews_article')) {
        global $post;
        if (!$post) return;

        $title = esc_attr($post->post_title);
        $description = esc_attr(wp_strip_all_tags($post->post_excerpt));
        $url = esc_url(get_permalink($post));
        $image_url = esc_url(get_post_meta($post->ID, '_edunews_image_url', true));

        // Meta Description
        echo '<meta name="description" content="' . $description . '" />' . "\n";

        // Open Graph Tags
        echo '<meta property="og:title" content="' . $title . '" />' . "\n";
        echo '<meta property="og:description" content="' . $description . '" />' . "\n";
        echo '<meta property="og:url" content="' . $url . '" />' . "\n";
        echo '<meta property="og:type" content="article" />' . "\n";
        if ($image_url) {
            echo '<meta property="og:image" content="' . $image_url . '" />' . "\n";
        }

        // Twitter Card Tags
        echo '<meta name="twitter:card" content="summary_large_image" />' . "\n"; // Use summary_large_image if images are prominent
        echo '<meta name="twitter:title" content="' . $title . '" />' . "\n";
        echo '<meta name="twitter:description" content="' . $description . '" />' . "\n";
        if ($image_url) {
            echo '<meta name="twitter:image" content="' . $image_url . '" />' . "\n";
        }
    }
}
add_action('wp_head', 'edunews_add_seo_meta_tags');

/**
 * Adds NewsArticle Schema.org JSON-LD to the head of single edunews_article pages.
 */
function edunews_add_newsarticle_schema() {
    if (is_singular('edunews_article')) {
        global $post;
        if (!$post) return;

        $schema = array(
            '@context' => 'https://schema.org',
            '@type' => 'NewsArticle',
            'headline' => $post->post_title,
            'datePublished' => get_post_time('c', true, $post),
            'dateModified' => get_post_modified_time('c', true, $post),
            'description' => wp_strip_all_tags($post->post_excerpt),
            // You might want to add author and publisher details if available
            // 'author' => array(
            //    '@type' => 'Person', // or 'Organization'
            //    'name' => 'Author Name'
            // ),
            // 'publisher' => array(
            //    '@type' => 'Organization',
            //    'name' => get_bloginfo('name'), // Site name as publisher
            //    'logo' => array(
            //        '@type' => 'ImageObject',
            //        'url' => 'URL_TO_YOUR_LOGO_IMAGE'
            //    )
            // )
        );

        $image_url = get_post_meta($post->ID, '_edunews_image_url', true);
        if ($image_url) {
            $schema['image'] = array(
                '@type' => 'ImageObject',
                'url' => $image_url,
                // Optionally add width and height if known
            );
        }

        echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
    }
}
add_action('wp_head', 'edunews_add_newsarticle_schema');

// Nascondi solo il pulsante "Aggiungi nuovo" ma mantieni altri pulsanti come "Svuota articoli"
function edunews_hide_add_new_button() {
    global $post_type;
    if ($post_type === 'edunews_article') {
        echo '<style>
            .add-new-h2, 
            .wrap .add-new-h2 {
                display: none !important;
            }
            /* Nascondi solo il primo page-title-action (che è "Aggiungi nuovo") */
            .wrap .page-title-action:first-of-type {
                display: none !important;
            }
        </style>';
    }
}
add_action('admin_head', 'edunews_hide_add_new_button');

// Funzione per pulire la vecchia tassonomia edunews_subcategory
function edunews_cleanup_old_subcategory_taxonomy() {
    global $wpdb;
    
    // Verifica se esiste la tassonomia
    $taxonomy_exists = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->term_taxonomy} WHERE taxonomy = %s",
        'edunews_subcategory'
    ));
    
    if ($taxonomy_exists > 0) {
        #error_log('EduNews: Rimozione della vecchia tassonomia edunews_subcategory...');
        
        // Rimuovi tutti i termini della tassonomia edunews_subcategory
        $wpdb->delete($wpdb->term_taxonomy, array('taxonomy' => 'edunews_subcategory'));
        
        // Pulisci i termini orfani (che non hanno più associazioni nella term_taxonomy)
        $wpdb->query("
            DELETE t FROM {$wpdb->terms} t
            LEFT JOIN {$wpdb->term_taxonomy} tt ON t.term_id = tt.term_id
            WHERE tt.term_id IS NULL
        ");
        
        #error_log('EduNews: Vecchia tassonomia edunews_subcategory rimossa completamente');
    }
    
    // Pulisci anche la cache relativa
    delete_transient('edunews_subcategories_cache');
}

// Funzione per convertire markdown semplice in HTML
function edunews_markdown_to_html($text) {
    if (empty($text)) {
        return '';
    }
    
    // Debug: vediamo i caratteri esatti se troviamo possibili markdown
    if (strpos($text, '#') !== false) {
        $first_hash_pos = strpos($text, '#');
        $sample = substr($text, max(0, $first_hash_pos - 5), 20);
        $hex_codes = '';
        for ($i = 0; $i < strlen($sample); $i++) {
            $hex_codes .= sprintf('%02X ', ord($sample[$i]));
        }
        error_log('EduNews Markdown HEX CODES: ' . $sample . ' = ' . $hex_codes);
    }
    
    // Debug: vediamo cosa arriva davvero dagli articoli (prima versione)
    if (strpos($text, '###') !== false || strpos($text, '##') !== false) {
        error_log('EduNews Markdown TROVATO ### - INPUT RAW: ' . substr($text, 0, 300));
    }
    
    // Decodifica entità HTML che potrebbero esserci
    $text = html_entity_decode($text, ENT_QUOTES, 'UTF-8');
    
    // Debug: vediamo dopo html_entity_decode
    if (strpos($text, '###') !== false || strpos($text, '##') !== false) {
        error_log('EduNews Markdown DOPO DECODE - INPUT: ' . substr($text, 0, 300));
    }
    
    // Escapa tutto l'HTML per sicurezza (dopo decode)
    $text = esc_html($text);
    
    // Converti i titoli markdown con approccio più robusto
    // ### Titolo 3
    $text = preg_replace('/^###\s+(.+)$/m', '<h3>$1</h3>', $text);
    // ## Titolo 2  
    $text = preg_replace('/^##\s+(.+)$/m', '<h2>$1</h2>', $text);
    // # Titolo 1
    $text = preg_replace('/^#\s+(.+)$/m', '<h1>$1</h1>', $text);
    
    // Anche senza spazi dopo ###
    $text = preg_replace('/^###(.+)$/m', '<h3>$1</h3>', $text);
    $text = preg_replace('/^##(.+)$/m', '<h2>$1</h2>', $text);
    $text = preg_replace('/^#(.+)$/m', '<h1>$1</h1>', $text);
    
    // AGGIUNTA: Prova anche con possibili caratteri Unicode simili
    // Alcuni siti usano caratteri "full-width" o altri simboli simili
    $text = preg_replace('/^＃＃＃\s*(.+)$/m', '<h3>$1</h3>', $text);
    $text = preg_replace('/^＃＃\s*(.+)$/m', '<h2>$1</h2>', $text);
    $text = preg_replace('/^＃\s*(.+)$/m', '<h1>$1</h1>', $text);
    
    // Pattern ancora più aggressivo per caratteri che sembrano #
    // Cerca 3 caratteri simili seguiti da spazio e testo
    $text = preg_replace('/^[#＃♯№]\s*[#＃♯№]\s*[#＃♯№]\s*(.+)$/m', '<h3>$1</h3>', $text);
    $text = preg_replace('/^[#＃♯№]\s*[#＃♯№]\s*(.+)$/m', '<h2>$1</h2>', $text);
    $text = preg_replace('/^[#＃♯№]\s*(.+)$/m', '<h1>$1</h1>', $text);
    
    // Converti grassetto e corsivo
    $text = preg_replace('/\*\*(.+?)\*\*/', '<strong>$1</strong>', $text);
    $text = preg_replace('/\*(.+?)\*/', '<em>$1</em>', $text);
    
    // Converti i link [testo](url)
    $text = preg_replace('/\[([^\]]+)\]\(([^)]+)\)/', '<a href="$2" target="_blank">$1</a>', $text);
    
    // Converti a capo doppi in paragrafi
    $paragraphs = explode("\n\n", trim($text));
    $html_paragraphs = array();
    
    foreach ($paragraphs as $paragraph) {
        $paragraph = trim($paragraph);
        if (!empty($paragraph)) {
            // Se non inizia già con un tag HTML, avvolgilo in <p>
            if (!preg_match('/^<(h[1-6]|div|ul|ol|blockquote)/', $paragraph)) {
                // Converti singoli a capo in <br>
                $paragraph = str_replace("\n", '<br>', $paragraph);
                $paragraph = '<p>' . $paragraph . '</p>';
            }
            $html_paragraphs[] = $paragraph;
        }
    }
    
    $result = implode("\n", $html_paragraphs);
    
    // Debug: mostra solo se c'erano ### nell'input o se sono stati convertiti
    if (strpos($result, '<h3>') !== false || strpos($result, '<h2>') !== false) {
        error_log('EduNews Markdown SUCCESS - OUTPUT: ' . substr($result, 0, 300));
    }
    
    return $result;
}

// Funzione per svuotamento automatico degli articoli all'attivazione
function edunews_auto_cleanup_articles() {
    #error_log('EduNews: Auto-cleanup degli articoli in corso durante l\'attivazione del plugin...');
    
    // Get all EduNews articles
    $articles = get_posts(array(
        'post_type' => 'edunews_article',
        'posts_per_page' => -1,
        'fields' => 'ids'
    ));

    if (!empty($articles)) {
        $deleted_count = 0;
        // Delete each article
        foreach ($articles as $article_id) {
            wp_delete_post($article_id, true);
            $deleted_count++;
        }
        
        #error_log('EduNews: Auto-cleanup completato. Eliminati ' . $deleted_count . ' articoli esistenti.');
    } else {
        #error_log('EduNews: Auto-cleanup - nessun articolo esistente da eliminare.');
    }

    // Clear the cache
    delete_transient('edunews_articles_cache');
    delete_transient('edunews_categories_cache');
    delete_transient('edunews_subcategories_cache');
    
    #error_log('EduNews: Cache svuotata dopo auto-cleanup.');
}

// Hook for immediate cleanup after plugin activation
add_action('edunews_immediate_cleanup_event', 'edunews_immediate_cleanup_with_sync');

function edunews_immediate_cleanup_with_sync() {
    #error_log('EduNews: Avvio auto-cleanup post-attivazione...');
    
    // Set update in progress flag for the entire activation process
    set_transient('edunews_update_in_progress', true, 120); // 2 minutes timeout for easier debugging
    #error_log('EduNews: Impostato flag sincronizzazione in corso per attivazione plugin');
    
    // Auto-cleanup completo
    edunews_auto_cleanup_articles();
    
    // Pulizia delle categorie numeriche e vecchie
    edunews_cleanup_numeric_categories();
    
    // Pulizia della vecchia tassonomia subcategory
    edunews_cleanup_old_subcategory_taxonomy();
    
    #error_log('EduNews: Auto-cleanup post-attivazione completato. Scheduling sincronizzazione immediata...');
    
    // Schedula una sincronizzazione una tantum subito (cleanup già completato)
    wp_schedule_single_event(time() + 1, 'edunews_immediate_sync_event');
    
    #error_log('EduNews: Sincronizzazione schedulata per 1 secondo (cleanup già completato).');
}

// Hook for immediate sync after plugin activation
add_action('edunews_immediate_sync_event', 'edunews_immediate_sync');

function edunews_immediate_sync() {
    #error_log('EduNews: Avvio sincronizzazione immediata post-attivazione...');
    
    // Don't set the transient here since it's already set by cleanup function
    // But ensure we clear it when done
    try {
        // Call the update function without setting the transient again
        edunews_update_articles_without_transient();
        #error_log('EduNews: Sincronizzazione immediata post-attivazione completata.');
    } catch (Exception $e) {
        #error_log('EduNews: Errore durante sincronizzazione immediata: ' . $e->getMessage());
    } finally {
        // Clear the transient when the entire activation process is done
        delete_transient('edunews_update_in_progress');
        #error_log('EduNews: Rimosso flag sincronizzazione in corso - attivazione plugin completata');
    }
}

// Add AJAX handler for checking sync status
add_action('wp_ajax_edunews_check_sync_status', 'edunews_ajax_check_sync_status');
function edunews_ajax_check_sync_status() {
    check_ajax_referer('edunews_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Permessi insufficienti']);
        return;
    }
    
    $is_syncing = get_transient('edunews_update_in_progress');
    $last_sync = get_option('edunews_last_sync', 'Mai');
    $next_sync = wp_next_scheduled('edunews_update_articles_event');
    
    // Calculate correct next sync time
    $next_sync_formatted = 'Mai';
    if ($last_sync !== 'Mai') {
        $last_sync_time = DateTime::createFromFormat('d/m/Y H:i:s', $last_sync);
        if ($last_sync_time !== false) {
            $interval = 20 * 60; // 20 minutes in seconds
            $correct_next_sync = $last_sync_time->getTimestamp() + $interval;
            $next_sync_formatted = date('d/m/Y H:i:s', $correct_next_sync);
        } else if ($next_sync) {
            $next_sync_formatted = date('d/m/Y H:i:s', $next_sync);
        }
    } else if ($next_sync) {
        $next_sync_formatted = date('d/m/Y H:i:s', $next_sync);
    }
    
    wp_send_json_success([
        'is_syncing' => (bool)$is_syncing,
        'last_sync' => $last_sync,
        'next_sync' => $next_sync_formatted
    ]);
}


