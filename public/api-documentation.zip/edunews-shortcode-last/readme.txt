=== News Posts by EduNews24.it: Edunews Shortcode  ===
Contributors: michelemonaco78
Tags: news, news posts, add news, Culture, School, Work, Ads Work, University News, Research News, World news, posts news by EduNews24.it, 
Requires at least: 3.3.0
Tested up to: 6.7
Stable tag: 1.1
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

EN: Plugin for wordpress that allows you to link free to the news on the online newspaper EduNews24.it. The import of news is absolutely free and related to the regulations imposed in the license, it is not possible to modify the articles as they are the result of the intellectual property of EduNews24.it and therefore reliable and verified source.
IT: Plugin per wordpress che permette di collegarsi gratuitamente alle notizie sul giornale online EduNews24.it. L'importazione di notizie è assolutamente gratuita e legata alle normative imposte nella licenza, non è possibile modificare gli articoli poichè sono frutto della propietà intellettuale di EduNews24.it e pertanto fonte attendibile e verificata.

== Description ==

https://edunews24.it/Plugin

EN: The plugin creates a new section in the wordpress menu that allows you to import articles according to the categories requested by the user for his wordpress site. The import of news is absolutely free, you will not be able to edit the articles as you like because they are the result of a reliable source. 
You can select the categories that interest you most and create shortcodes for insertion on wordpress pages in List, Grid and Slider mode. 

IT: Il plugin crea una nuova sezione nel menù di wordpress che ti permette di importare gli articoli secondo le categorie richieste dall'utente per il suo sito wordpress. L'importazione delle notizie è assolutamente gratuito, non potrai modificare gli articoli a tuo piacimento poichè sono frutto di una fonte attendibile. 
Potrai selezionare le categorie che più ti interessano e creare degli shortcode per l'inserimento sulle pagine wordpress in modalità Lista, Griglia e Slider. 

== Installation ==

### First you need to download the plugin ZIP file.  

1. Log in to your admin panel.   
2. Go to Plugins page, click on Add New, then click "Upload Plugin" .    
3. Then click "Choose file" then select the plugin .zip file. 
4. Then install and activate the plugin.     
 
== Frequently Asked Questions ==

Our plugin is user friendly, but here you can view some frequently asked questions that can help you.

= What files I need to upload for installing the plugin =

You need to select the .zip file, there is no need to extract the zip file, just upload it.

== Screenshots ==

1.  Front-end    
2.  Front-end
3.  Front-end           
4.  Back-end     
5.  Back-end
6.  Back-end
7.  Back-end

== Changelog ==

= 1.0.0 =

*  Initial version.

