<?php
if (!isset($articles) || empty($articles)) {
    echo '<p>Nessun articolo da mostrare.</p>';
    return;
}
?>
<div class="edunews-grid">
    <?php foreach ($articles as $article): ?>
        <div class="edunews-grid-item">
            <div class="edunews-article">
                <?php if (!empty($article['image_url'])): ?>
                    <?php
                // Usa title_summary se disponibile, altrimenti usa title
                $title_to_use = isset($article['title_summary']) && !empty($article['title_summary']) ? $article['title_summary'] : $article['title'];
                ?>
                <img src="<?php echo esc_url($article['image_url']); ?>" alt="<?php echo esc_attr($title_to_use); ?>" loading="lazy">
                <?php endif; ?>
                <div class="edunews-article-content">
                    <h3><a href="<?php echo esc_url($article['url']); ?>" target="_blank"><?php echo esc_html($title_to_use); ?></a></h3>
                    
                    <div class="edunews-article-meta">
                        <span class="edunews-date"><?php echo esc_html(date('d/m/Y', strtotime($article['published_at']))); ?></span>
                        <?php if (!empty($article['category'])): ?>
                            <span class="edunews-category"><?php echo esc_html($article['category']); ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <?php if (!empty($article['audio_url'])): ?>
                        <audio controls style="width:100%;margin-top:8px;">
                            <source src="<?php echo esc_url($article['audio_url']); ?>" type="audio/mpeg">
                            Il tuo browser non supporta l'audio HTML5.
                        </audio>
                    <?php endif; ?>
                    
                    <div class="edunews-article-footer" style="display: flex; justify-content: center;">
                        <a href="<?php echo esc_url($article['url']); ?>" target="_blank" rel="noopener" class="edunews-read-more">Leggi tutto</a>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div> 