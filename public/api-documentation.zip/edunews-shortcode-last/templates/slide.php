<?php
if (!defined('ABSPATH')) exit;

if (!isset($articles) || empty($articles)) {
    echo '<p>Nessun articolo da mostrare.</p>';
    return;
}
?>

<div class="splide edunews-splide">
    <div class="splide__track">
        <ul class="splide__list">
            <?php foreach ($articles as $article): ?>
                <li class="splide__slide">
                    <div class="edunews-article">
                        <?php if (!empty($article['image_url'])): ?>
                            <?php
                            $title_to_use = isset($article['title_summary']) && !empty($article['title_summary']) ? $article['title_summary'] : $article['title'];
                            ?>
                            <img src="<?php echo esc_url($article['image_url']); ?>" alt="<?php echo esc_attr($title_to_use); ?>" loading="lazy">
                        <?php endif; ?>
                        <div class="edunews-article-content">
                            <h3><a href="<?php echo esc_url($article['url']); ?>" target="_blank"><?php echo esc_html($title_to_use); ?></a></h3>
                            
                            <div class="edunews-article-meta">
                                <span class="edunews-date"><?php echo esc_html(date('d/m/Y', strtotime($article['published_at']))); ?></span>
                                <?php if (!empty($article['category'])): ?>
                                    <span class="edunews-category"><?php echo esc_html($article['category']); ?></span>
                                <?php endif; ?>
                            </div>
                            
                            <?php if (!empty($article['audio_url'])): ?>
                                <audio controls style="width:100%;margin-top:8px;">
                                    <source src="<?php echo esc_url($article['audio_url']); ?>" type="audio/mpeg">
                                    Il tuo browser non supporta l'audio HTML5.
                                </audio>
                            <?php endif; ?>
                            
                            <div class="edunews-article-footer">
                                <a href="<?php echo esc_url($article['url']); ?>" target="_blank" rel="noopener" class="edunews-read-more">Leggi tutto</a>
                            </div>
                        </div>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</div>

<style>
.edunews-slider {
    position: relative;
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}

.edunews-title {
    text-align: center;
    margin-bottom: 30px;
    color: #333;
}

.edunews-slider-container {
    display: flex;
    overflow: hidden;
    position: relative;
}

.edunews-slide {
    flex: 0 0 100%;
    padding: 20px;
    box-sizing: border-box;
}

.edunews-article {
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    padding: 20px;
    height: 100%;
}

.edunews-article-title {
    margin: 0 0 15px;
    font-size: 1.5em;
}

.edunews-article-title a {
    color: #333;
    text-decoration: none;
}

.edunews-article-title a:hover {
    color: #0073aa;
}

.edunews-article-meta {
    margin-bottom: 15px;
    color: #666;
    font-size: 0.9em;
}

.edunews-article-excerpt {
    margin-bottom: 20px;
    line-height: 1.6;
}

.edunews-article-links {
    display: flex;
    gap: 15px;
}

.edunews-read-more,
.edunews-read-original {
    display: inline-block;
    padding: 8px 16px;
    border-radius: 4px;
    text-decoration: none;
    font-weight: 500;
    transition: all 0.3s ease;
}

.edunews-read-more {
    background: #0073aa;
    color: #fff;
}

.edunews-read-original {
    background: #f0f0f0;
    color: #333;
}

.edunews-read-more:hover {
    background: #005177;
    color: #fff;
}

.edunews-read-original:hover {
    background: #e0e0e0;
}

.edunews-slider-controls {
    position: absolute;
    top: 50%;
    width: 100%;
    transform: translateY(-50%);
    display: flex;
    justify-content: space-between;
    pointer-events: none;
}

.edunews-prev,
.edunews-next {
    background: rgba(255,255,255,0.9);
    border: none;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    font-size: 20px;
    cursor: pointer;
    pointer-events: auto;
    transition: all 0.3s ease;
}

.edunews-prev:hover,
.edunews-next:hover {
    background: #fff;
    box-shadow: 0 2px 4px rgba(0,0,0,0.2);
}
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        var splideEls = document.querySelectorAll('.edunews-splide');
        splideEls.forEach(function(splideEl) {
            if (!splideEl.classList.contains('is-initialized')) {
                new Splide(splideEl, {
                    perPage: 4,
                    perMove: 1,
                    gap: '2rem',
                    pagination: true,
                    arrows: true,
                    autoHeight: true,
                    breakpoints: {
                        1024: { perPage: 3, gap: '1.5rem' },
                        768: { perPage: 2, gap: '1rem' },
                        640: {
                            perPage: 1,
                            fixedWidth: '85%',
                            focus: 'center',
                            gap: '1.5rem',
                            padding: 0,
                            trimSpace: false,
                            arrows: true,
                            pagination: true
                        }
                    }
                }).mount();
                splideEl.classList.add('is-initialized');
            }
        });
    });
</script> 