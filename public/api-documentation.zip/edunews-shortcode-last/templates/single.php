<?php
if (!defined('ABSPATH')) exit;

function edunews_template_meta_tags() {
    global $post;
    if (!$post) return;
    
    $keywords = get_post_meta($post->ID, '_edunews_keywords', true);
    
    if (is_array($keywords)) {
        $keywords = implode(', ', $keywords);
    }
    
    if (!empty($keywords)) {
        if (strpos($keywords, 'EduNews24.it') === false) {
            $keywords .= ', EduNews24.it';
        }
    } else {
        $keywords = 'EduNews24.it';
    }
    
    echo '<meta name="description" content="EduNews24.it - ' . esc_attr($post->post_title) . '" />' . "\n";
    echo '<meta name="keywords" content="' . esc_attr($keywords) . '" />' . "\n";
}

add_action('wp_head', 'edunews_template_meta_tags', 1);

$post = get_post();
if (!$post) {
    wp_die('Articolo non trovato');
}

$original_url = get_post_meta($post->ID, '_edunews_original_url', true);
$published_at = get_post_meta($post->ID, '_edunews_published_at', true);
$image_url = get_post_meta($post->ID, '_edunews_image_url', true);

get_header();
?>

<div class="edunews-single-article">
    <article class="edunews-article-content">
        <header class="edunews-article-header">
            <?php if ($image_url) : ?>
                <div class="edunews-article-image">
                    <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($post->post_title); ?>" class="edunews-featured-image" loading="lazy" />
                </div>
            <?php endif; ?>

            <h1 class="edunews-article-title"><?php echo esc_html($post->post_title); ?></h1>
            
            <div class="edunews-article-meta">
                <span class="edunews-article-date">
                    <?php echo esc_html(date_i18n(get_option('date_format'), strtotime($published_at ?: $post->post_date))); ?>
                </span>
                <?php
                $categories = get_the_terms($post->ID, 'edunews_category');
                if ($categories && !is_wp_error($categories)) {
                    echo '<span class="edunews-article-category">';
                    foreach ($categories as $category) {
                        echo '<a href="' . esc_url(get_term_link($category)) . '">' . esc_html($category->name) . '</a>';
                    }
                    echo '</span>';
                }
                ?>
                <?php if ($original_url) : ?>
                    <a href="<?php echo esc_url($original_url); ?>" target="_blank">
                        Leggi l'articolo completo su EduNews24.it
                    </a>
                <?php endif; ?>
            </div>
        </header>

        <div class="edunews-article-body">
            <div class="edunews-content">
                <?php 
                // Usa post_content se disponibile, altrimenti post_excerpt
                $content_to_display = !empty($post->post_content) ? $post->post_content : $post->post_excerpt;
                echo edunews_markdown_to_html($content_to_display); 
                ?>
            </div>
        </div>

        <footer class="edunews-article-footer">
            <div class="edunews-article-links">
            </div>
        </footer>
    </article>
</div>

<style>
.edunews-article-meta {
    display: flex;
    flex-direction: column;
    gap: 8px;
    margin: 15px 0;
}

.edunews-article-date {
    color: #666;
    font-size: 14px;
}

.edunews-article-category {
    display: flex;
    flex-wrap: wrap;
    gap: 8px 12px; /* 8px verticale, 12px orizzontale */
    line-height: 1.4;
    align-items: center;
}

.edunews-article-category a {
    color: #2271b1;
    text-decoration: none;
    font-weight: 500;
    padding: 2px 6px;
    border-radius: 3px;
    background-color: #f0f6fc;
    border: 1px solid #c3d9ed;
    transition: all 0.2s ease;
    white-space: nowrap;
}

.edunews-article-category a:hover {
    background-color: #2271b1;
    color: white;
    border-color: #2271b1;
}

/* Separatori tra le categorie */
.edunews-article-category a:not(:last-child)::after {
    content: "";
    margin: 0; /* Rimuoviamo il separatore • dato che ora abbiamo i tag */
}

.edunews-article-meta > a {
    color: #2271b1;
    text-decoration: none;
    font-weight: 500;
    margin-top: 5px;
    display: inline-block;
}

.edunews-article-meta > a:hover {
    text-decoration: underline;
}

/* Responsive per mobile */
@media (max-width: 768px) {
    .edunews-article-category {
        gap: 6px 8px;
    }
    
    .edunews-article-category a {
        font-size: 13px;
        padding: 1px 4px;
    }
}
</style>

<?php
get_footer();
?> 