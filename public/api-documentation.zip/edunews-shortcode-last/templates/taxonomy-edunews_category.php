<?php
if (!defined('ABSPATH')) exit;

get_header();

$term = get_queried_object();
$category_name = $term ? $term->name : 'Categoria EduNews';
?>

<div class="edunews-category-archive">
    <header class="edunews-archive-header">
        <h1 class="edunews-archive-title">Categoria EduNews: <?php echo esc_html($category_name); ?></h1>
    </header>

    <div class="edunews-archive-content">
        <?php
        if (have_posts()) :
            while (have_posts()) : the_post();
                $post_id = get_the_ID();
                $image_url = get_post_meta($post_id, '_edunews_image_url', true);
                $published_at = get_post_meta($post_id, '_edunews_published_at', true);
                $original_url = get_post_meta($post_id, '_edunews_original_url', true);
                
                ?>
                
                <article class="edunews-archive-article">
                    <div class="edunews-archive-item">
                        <?php if ($image_url) : ?>
                            <div class="edunews-archive-image">
                                <a href="<?php the_permalink(); ?>">
                                    <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr(get_the_title()); ?>" loading="lazy" />
                                </a>
                            </div>
                        <?php endif; ?>
                        
                        <div class="edunews-archive-text">
                            <h2 class="edunews-archive-article-title">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h2>
                            
                            <div class="edunews-archive-meta">
                                <span class="edunews-archive-date">
                                    <?php echo esc_html(date_i18n(get_option('date_format'), strtotime($published_at ?: get_the_date()))); ?>
                                </span>
                                
                                <?php if ($original_url) : ?>
                                    <a href="<?php echo esc_url($original_url); ?>" target="_blank" class="edunews-archive-link">
                                        Leggi l'articolo completo su EduNews24.it
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </article>
                
                <?php
            endwhile;
            
            // Paginazione
            the_posts_pagination(array(
                'prev_text' => '← Pagina precedente',
                'next_text' => 'Pagina successiva →',
            ));
            
        else :
            ?>
            <p>Nessun articolo trovato in questa categoria.</p>
            <?php
        endif;
        ?>
    </div>
</div>

<style>
.edunews-category-archive {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}

.edunews-archive-header {
    margin-bottom: 30px;
    text-align: center;
}

.edunews-archive-title {
    font-size: 2.5em;
    margin: 0;
    color: #333;
}

.edunews-archive-content {
    display: flex;
    flex-direction: column;
    gap: 30px;
}

.edunews-archive-article {
    border-bottom: 1px solid #e0e0e0;
    padding-bottom: 30px;
}

.edunews-archive-item {
    display: flex;
    gap: 20px;
    align-items: flex-start;
}

.edunews-archive-image {
    flex-shrink: 0;
    width: 300px;
}

.edunews-archive-image img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    border-radius: 8px;
}

.edunews-archive-text {
    flex: 1;
}

.edunews-archive-article-title {
    font-size: 1.5em;
    margin: 0 0 15px 0;
}

.edunews-archive-article-title a {
    color: #333;
    text-decoration: none;
}

.edunews-archive-article-title a:hover {
    color: #2271b1;
}



.edunews-archive-meta {
    display: flex;
    gap: 15px;
    align-items: center;
    font-size: 0.9em;
    color: #999;
}

.edunews-archive-link {
    color: #2271b1;
    text-decoration: none;
}

.edunews-archive-link:hover {
    text-decoration: underline;
}

/* Responsive */
@media (max-width: 768px) {
    .edunews-archive-item {
        flex-direction: column;
    }
    
    .edunews-archive-image {
        width: 100%;
    }
    
    .edunews-archive-title {
        font-size: 2em;
    }
}
</style>

<?php
get_footer();
?> 