<?php
if (!isset($articles) || empty($articles)) {
    echo '<p>Nessun articolo da mostrare.</p>';
    return;
}
?>
<div class="edunews-simple-list">
    <?php foreach ($articles as $index => $article): ?>
        <div class="edunews-list-item edunews-no-hover">
            <div class="edunews-list-inner">
                <?php if (!empty($article['image_url'])): ?>
                    <div class="edunews-list-image">
                        <?php
                        // Usa title_summary se disponibile, altrimenti usa title
                        $title_to_use = isset($article['title_summary']) && !empty($article['title_summary']) ? $article['title_summary'] : $article['title'];
                        ?>
                        <img src="<?php echo esc_url($article['image_url']); ?>" alt="<?php echo esc_attr($title_to_use); ?>" loading="lazy">
                    </div>
                <?php endif; ?>
                <div class="edunews-list-content">
                    <h3><a href="<?php echo esc_url($article['url']); ?>" target="_blank" class="edunews-no-hover-link"><?php echo esc_html($title_to_use); ?></a></h3>
                    
                    <div class="edunews-article-meta">
                        <span class="edunews-date"><?php echo esc_html(date('d/m/Y', strtotime($article['published_at']))); ?></span>
                        <?php if (!empty($article['category'])): ?>
                            <span class="edunews-category"><?php echo esc_html($article['category']); ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <?php if (!empty($article['audio_url'])): ?>
                        <audio controls style="width:100%;margin-top:8px;">
                            <source src="<?php echo esc_url($article['audio_url']); ?>" type="audio/mpeg">
                            Il tuo browser non supporta l'audio HTML5.
                        </audio>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php if ($index < count($articles) - 1): ?>
            <hr class="edunews-list-divider">
        <?php endif; ?>
    <?php endforeach; ?>
</div>

<style>
/* Stili per sovrascrivere completamente gli effetti hover */
.edunews-simple-list {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
    max-width: 900px;
    background: transparent;
    margin: 0 auto;
    padding: 0 15px;
}

/* Questi selettori avranno priorità sul CSS globale */
.edunews-simple-list .edunews-list-item.edunews-no-hover,
.edunews-simple-list .edunews-no-hover {
    background: transparent !important;
    border: none !important;
    box-shadow: none !important;
    transform: none !important;
    transition: none !important;
    animation: none !important;
    padding: 0 !important;
    border-radius: 0 !important;
}

/* Prevenzione esplicita dell'hover */
.edunews-simple-list .edunews-list-item.edunews-no-hover:hover,
.edunews-simple-list .edunews-no-hover:hover {
    background: transparent !important;
    border: none !important;
    box-shadow: none !important;
    transform: none !important;
    transition: none !important;
    animation: none !important;
}

.edunews-list-inner {
    display: flex;
    align-items: flex-start;
    gap: 20px;
    padding: 10px 0;
    background: transparent;
}

.edunews-list-image {
    flex: 0 0 120px;
}

.edunews-list-image img {
    width: 100%;
    height: auto;
    border-radius: 0;
    object-fit: cover;
}

.edunews-list-content {
    flex: 1;
    background: transparent;
    border: none;
    padding: 0;
    box-shadow: none;
}

.edunews-list-content h3 {
    margin: 0 0 10px 0;
    font-size: 18px;
    line-height: 1.4;
}

/* Stile per il link senza hover */
.edunews-list-content h3 a.edunews-no-hover-link {
    color: #333 !important;
    text-decoration: none !important;
    transition: none !important;
}

/* Assicurazione che l'hover non abbia effetti */
.edunews-list-content h3 a.edunews-no-hover-link:hover,
.edunews-list-content h3 a.edunews-no-hover-link:focus,
.edunews-list-content h3 a.edunews-no-hover-link:active {
    color: #333 !important;
    text-decoration: none !important;
    background: transparent !important;
    border: none !important;
    outline: none !important;
    box-shadow: none !important;
    transform: none !important;
    opacity: 1 !important;
}

.edunews-article-meta {
    font-size: 14px;
    color: #666;
    margin-bottom: 8px;
}

.edunews-category {
    margin-left: 10px;
    padding: 2px 8px;
    background-color: #e9e9e9;
    border-radius: 3px;
    font-size: 12px;
    display: inline-block;
}

.edunews-list-divider {
    border: 0;
    height: 1px;
    background-color: #eaeaea;
    margin: 15px 0;
}

/* Reset universale di tutti gli effetti per gli elementi nella lista */
.edunews-simple-list *,
.edunews-simple-list *::before,
.edunews-simple-list *::after {
    transition: none !important;
    animation: none !important;
    transform: none !important;
}

/* Responsive */
@media (max-width: 767px) {
    .edunews-list-inner {
        flex-direction: column;
    }
    
    .edunews-list-image {
        flex: 0 0 auto;
        width: 100%;
        margin-bottom: 10px;
    }
}

/* Questo è un reset forzato che va applicato dopo il caricamento della pagina */
.edunews-simple-list .reset-hover {
    all: initial !important;
    all: unset !important;
    transform: none !important;
}
</style>

<script>
// Script per assicurarsi che tutti gli effetti hover vengano rimossi anche dopo il caricamento
document.addEventListener('DOMContentLoaded', function() {
    var listItems = document.querySelectorAll('.edunews-simple-list .edunews-list-item');
    listItems.forEach(function(item) {
        // Aggiungiamo una classe di reset anche via JavaScript
        item.classList.add('reset-hover');
        
        // Preveniamo qualsiasi transizione o animazione via JavaScript
        item.style.transition = 'none';
        item.style.transform = 'none';
        item.style.boxShadow = 'none';
        
        // Aggiungiamo un listener per prevenire l'hover
        item.addEventListener('mouseenter', function(e) {
            this.style.transform = 'none';
            this.style.boxShadow = 'none';
        });
    });
});
</script> 