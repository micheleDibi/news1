<?php
/**
 * Admin page for EduNews Shortcode management
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

function edunews_admin_menu() {
    #error_log('EduNews: Registering admin menu');
    add_submenu_page(
        'edit.php?post_type=edunews_article', // parent slug
        'EduNews Shortcode', // page title
        'Gestione Shortcode', // menu title
        'manage_options', // capability
        'edunews-shortcode', // menu slug
        'edunews_admin_page' // function to display the page
    );
    #error_log('EduNews: Admin menu registered as submenu of Articoli EduNews');
}
add_action('admin_menu', 'edunews_admin_menu');


function edunews_register_settings() {
    register_setting('edunews_options', 'edunews_saved_shortcodes', array(
        'type' => 'array',
        'sanitize_callback' => 'edunews_sanitize_shortcodes',
        'default' => array(),
    ));
}
add_action('admin_init', 'edunews_register_settings');


function edunews_sanitize_shortcodes($shortcodes) {
    if (!is_array($shortcodes)) {
        return array();
    }
    
    foreach ($shortcodes as $key => $shortcode) {
        $shortcodes[$key]['name'] = sanitize_text_field($shortcode['name']);
        $shortcodes[$key]['title'] = sanitize_text_field($shortcode['title']);
        $shortcodes[$key]['display_mode'] = sanitize_text_field($shortcode['display_mode']);
        $shortcodes[$key]['category'] = sanitize_text_field($shortcode['category']);
        $shortcodes[$key]['categories'] = is_array($shortcode['categories']) ? array_map('sanitize_text_field', $shortcode['categories']) : [];
        $shortcodes[$key]['subcategories'] = is_array($shortcode['subcategories']) ? array_map('sanitize_text_field', $shortcode['subcategories']) : [];
        $shortcodes[$key]['post_ids'] = is_array($shortcode['post_ids']) ? array_map('sanitize_text_field', $shortcode['post_ids']) : [];
    }
    
    return $shortcodes;
}


function edunews_admin_scripts($hook) {
    #error_log('EduNews: Loading admin scripts for hook: ' . $hook);
    if ('edunews_article_page_edunews-shortcode' !== $hook) {
        #error_log('EduNews: Not the correct page, skipping script load');
        return;
    }
    
    #error_log('EduNews: Loading scripts for EduNews admin page');
    // Aggiungo Select2
    wp_enqueue_style('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css');
    wp_enqueue_script('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', array('jquery'), '4.1.0', true);
    
    wp_enqueue_style('edunews-admin-style', plugin_dir_url(__FILE__) . 'assets/admin-style.css', array(), '1.0.0');
    wp_enqueue_script('edunews-admin-script', plugin_dir_url(__FILE__) . 'assets/admin-script.js', array('jquery', 'select2'), '1.0.0', true);
    
    wp_localize_script('edunews-admin-script', 'edunews_admin', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('edunews_admin_nonce')
    ]);
}
add_action('admin_enqueue_scripts', 'edunews_admin_scripts');


function edunews_admin_page() {


    #error_log('EduNews: Starting edunews_admin_page function');

    if (!current_user_can('manage_options')) {
        #error_log('EduNews: User does not have manage_options capability');
        return;
    }
    
    if (isset($_POST['edunews_save_shortcode']) && isset($_POST['edunews_nonce']) && wp_verify_nonce($_POST['edunews_nonce'], 'edunews_save_shortcode')) {
        $shortcode_name = isset($_POST['shortcode_name']) ? sanitize_text_field($_POST['shortcode_name']) : '';
        $title = isset($_POST['title']) ? sanitize_text_field($_POST['title']) : '';
        $display_mode = isset($_POST['display_mode']) ? sanitize_text_field($_POST['display_mode']) : 'slide';
        $categories = isset($_POST['categories']) ? array_map('sanitize_text_field', $_POST['categories']) : [];
        $subcategories = isset($_POST['subcategories']) ? array_map('sanitize_text_field', $_POST['subcategories']) : [];
        
        // Controlla se la checkbox "mostra tutti" è selezionata
        $show_all = isset($_POST['show_all_posts']) && $_POST['show_all_posts'] === 'on';
        $max_posts = $show_all ? 0 : (isset($_POST['max_posts']) ? intval($_POST['max_posts']) : 10);
        
        if (!empty($shortcode_name)) {
            $saved_shortcodes = get_option('edunews_saved_shortcodes', array());
            
            // Create unique ID for the shortcode
            $shortcode_id = 'sc_' . time() . '_' . mt_rand(100, 999);
            
            $saved_shortcodes[$shortcode_id] = array(
                'name' => $shortcode_name,
                'title' => $title,
                'display_mode' => $display_mode,
                'categories' => $categories,
                'subcategories' => $subcategories,
                'max_posts' => $max_posts,
                'show_all' => $show_all
            );
            
            update_option('edunews_saved_shortcodes', $saved_shortcodes);
            echo '<div class="notice notice-success is-dismissible"><p>Shortcode salvato con successo!</p></div>';
        }
    }
    

    if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['shortcode_id']) && isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'delete_shortcode_' . $_GET['shortcode_id'])) {
        $shortcode_id = sanitize_text_field($_GET['shortcode_id']);
        $saved_shortcodes = get_option('edunews_saved_shortcodes', array());
        
        if (isset($saved_shortcodes[$shortcode_id])) {
            unset($saved_shortcodes[$shortcode_id]);
            update_option('edunews_saved_shortcodes', $saved_shortcodes);
            echo '<div class="notice notice-success is-dismissible"><p>Shortcode eliminato con successo!</p></div>';
        }
    }
    

    $saved_shortcodes = get_option('edunews_saved_shortcodes', array());
    

    #error_log('EduNews: About to call edunews_get_categories()');
    $categories = edunews_get_categories();
    #error_log('EduNews: Categories returned: ' . print_r($categories, true));
    
    // Recupera anche le sottocategorie
    #error_log('EduNews: About to call edunews_get_subcategories()');
    $subcategories = edunews_get_subcategories();
    #error_log('EduNews: Subcategories returned: ' . print_r($subcategories, true));

    $all_articles = edunews_get_articles();
    

    ?>
    <div class="wrap edunews-admin">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        
        <div class="edunews-sync-info">
            <?php 
            $last_sync = get_option('edunews_last_sync', 'Mai');
            $is_syncing = get_transient('edunews_update_in_progress');
            $next_sync = wp_next_scheduled('edunews_update_articles_event');
            ?>
            <div class="sync-times">
                <p class="last-sync">
                    Ultima sincronizzazione: <strong><?php echo esc_html($last_sync); ?></strong>
                </p>
                <?php if ($next_sync) : ?>
                <p class="next-sync">
                    Prossima sincronizzazione: <strong><?php 
                    // Calcoliamo il prossimo evento aggiungendo l'intervallo (20 minuti) all'ultima sincronizzazione 
                    // invece di usare wp_next_scheduled che potrebbe non essere aggiornato
                    
                    // Verifica se $last_sync è una data valida
                    if ($last_sync === 'Mai') {
                        // Se non è mai stata fatta una sincronizzazione, usa il timestamp programmato
                        echo esc_html(date('d/m/Y H:i:s', $next_sync));
                    } else {
                        // Prova a convertire la data italiana in timestamp
                        $last_sync_time = DateTime::createFromFormat('d/m/Y H:i:s', $last_sync);
                        if ($last_sync_time !== false) {
                            $interval = 20 * 60; // 20 minuti in secondi
                            $correct_next_sync = $last_sync_time->getTimestamp() + $interval;
                            echo esc_html(date('d/m/Y H:i:s', $correct_next_sync));
                        } else {
                            // Fallback: usa il timestamp programmato se non riusciamo a parsare la data
                            echo esc_html(date('d/m/Y H:i:s', $next_sync));
                        }
                    }
                    ?></strong>
                </p>
                <?php endif; ?>
            </div>
            <button id="force-sync" class="button button-secondary" <?php echo $is_syncing ? 'disabled' : ''; ?>>
                <?php echo $is_syncing ? 'Sincronizzazione in corso...' : 'Forza sincronizzazione'; ?>
            </button>
            <!--<button id="clear-sync" class="button button-secondary" style="margin-left: 10px;">
                🧹 Reset Sync Status
            </button>-->
        </div>
        
        <div class="edunews-admin-content" style="display: flex; gap: 20px; align-items: flex-start;">
            <div class="edunews-card" style="flex: 1; min-width: 400px;">
                <h2>Crea Nuovo Shortcode</h2>
                <form method="post" action="" id="edunews-shortcode-form">
                    <?php wp_nonce_field('edunews_save_shortcode', 'edunews_nonce'); ?>
                    
                    <div class="form-group">
                        <label for="shortcode_name">Nome Shortcode:</label>
                        <input type="text" id="shortcode_name" name="shortcode_name" class="regular-text" required>
                        <p class="description">Un nome descrittivo per identificare questo shortcode</p>
                    </div>
                    
                    <div class="form-group">
                        <label for="title">Titolo:</label>
                        <input type="text" id="title" name="title" class="regular-text">
                        <p class="description">Titolo da mostrare sopra la lista degli articoli (opzionale)</p>
                    </div>
                    
                    <div class="form-group">
                        <label for="display_mode">Modalità di visualizzazione:</label>
                        <select id="display_mode" name="display_mode" class="regular-text">
                            <option value="slide">Slider</option>
                            <option value="grid">Griglia</option>
                            <option value="list">Elenco</option>
                        </select>
                        <p class="description">Scegli come visualizzare gli articoli</p>
                    </div>
                    
                    <div class="form-group">
                        <label for="categories">Categorie:</label>
                        <select id="categories" name="categories[]" class="regular-text select2-categories" multiple="multiple">
                            <?php
                            if (!empty($categories)) {
                                foreach ($categories as $category) {
                                    echo '<option value="' . esc_attr($category['slug']) . '">' . esc_html($category['name']) . '</option>';
                                }
                            }
                            ?>
                        </select>
                        <p class="description">Seleziona una o più categorie da cui mostrare gli articoli</p>
                    </div>

                    <div class="form-group" id="subcategories-group" style="display: none;">
                        <label for="subcategories">Sottocategorie:</label>
                        <select id="subcategories" name="subcategories[]" class="regular-text select2-subcategories" multiple="multiple">
                            <!-- Le opzioni verranno popolate dinamicamente via AJAX -->
                        </select>
                        <p class="description">Seleziona una o più sottocategorie</p>
                    </div>

                    <div class="form-group">
                        <label for="max_posts">Numero massimo di articoli:</label>
                        <div class="max-posts-container" style="display: flex; align-items: center; gap: 10px;">
                            <input type="number" id="max_posts" name="max_posts" class="small-text" min="1" value="10">
                            <label class="show-all-checkbox">
                                <input type="checkbox" id="show_all_posts" name="show_all_posts"> Mostra tutti gli articoli
                            </label>
                        </div>
                        <p class="description">Numero massimo di articoli da mostrare per questo shortcode (seleziona "Mostra tutti" per visualizzarli tutti). Il sistema ora scarica TUTTI gli articoli dall'API</p>
                    </div>
                    
                    <p class="submit">
                        <input type="submit" name="edunews_save_shortcode" class="button button-primary" value="Salva Shortcode">
                    </p>
                </form>

                <style>
                    /* Fix per i campi Select2 */
                    .select2-container {
                        width: 100% !important;
                        max-width: 100%;
                    }
                    
                    .select2-selection--multiple {
                        min-height: 36px !important;
                        height: auto !important;
                        border: 1px solid #8c8f94 !important;
                        border-radius: 4px !important;
                        box-sizing: border-box !important;
                    }
                    
                    .select2-selection__rendered {
                        padding: 6px 8px !important;
                        line-height: 24px !important;
                        box-sizing: border-box !important;
                        display: flex !important;
                        align-items: center !important;
                        flex-wrap: wrap !important;
                        min-height: 24px !important;
                    }
                    
                    .select2-selection__placeholder {
                        color: #6c757d !important;
                        line-height: 24px !important;
                        margin: 0 !important;
                        padding: 0 !important;
                    }
                    
                    .select2-search--inline {
                        float: none !important;
                        line-height: 24px !important;
                    }
                    
                    .select2-search__field {
                        height: 24px !important;
                        line-height: 24px !important;
                        padding: 0 !important;
                        margin: 0 !important;
                        border: none !important;
                        outline: none !important;
                    }
                    
                    .select2-selection__choice {
                        margin: 2px 4px 2px 0 !important;
                        padding: 2px 8px !important;
                        line-height: 20px !important;
                        height: auto !important;
                        background-color: #e9ecef !important;
                        border: 1px solid #ced4da !important;
                        border-radius: 3px !important;
                    }
                    
                    .select2-dropdown {
                        border: 1px solid #8c8f94 !important;
                        border-radius: 4px !important;
                        z-index: 9999 !important;
                    }
                    
                    /* Assicura che i form groups abbiano spazio sufficiente */
                    .form-group {
                        margin-bottom: 20px;
                    }
                    
                    .form-group label {
                        display: block;
                        margin-bottom: 5px;
                        font-weight: 600;
                    }
                    
                    .form-group .description {
                        margin-top: 5px;
                        font-style: italic;
                        color: #666;
                    }
                    
                    /* Fix specifico per WordPress admin */
                    .wp-admin .select2-container .select2-selection--multiple {
                        background-color: #fff !important;
                    }
                    
                    .wp-admin .select2-container--default .select2-selection--multiple .select2-selection__rendered {
                        padding-left: 8px !important;
                        padding-right: 8px !important;
                    }
                </style>

                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        var maxPostsInput = document.getElementById('max_posts');
                        var showAllCheckbox = document.getElementById('show_all_posts');
                        
                        if (maxPostsInput && showAllCheckbox) {
                            showAllCheckbox.addEventListener('change', function() {
                                if (this.checked) {
                                    maxPostsInput.value = '0';
                                    maxPostsInput.disabled = true;
                                } else {
                                    maxPostsInput.value = '10';
                                    maxPostsInput.disabled = false;
                                }
                            });
                        }

                        // Gestione dinamica delle sottocategorie
                        var categoriesSelect = document.getElementById('categories');
                        var subcategoriesSelect = document.getElementById('subcategories');
                        var subcategoriesGroup = document.getElementById('subcategories-group');
                        
                        if (categoriesSelect && subcategoriesSelect && subcategoriesGroup && window.jQuery) {
                            // Inizializza Select2
                            jQuery(categoriesSelect).select2({
                                placeholder: 'Seleziona le categorie',
                                allowClear: true,
                                width: '100%'
                            });
                            
                            jQuery(subcategoriesSelect).select2({
                                placeholder: 'Seleziona le sottocategorie',
                                allowClear: true,
                                width: '100%'
                            });
                            
                            // Gestione del cambio di categoria per caricare le sottocategorie
                            jQuery(categoriesSelect).on('change', function() {
                                var selectedCategories = jQuery(this).val() || [];
                                
                                if (selectedCategories.length === 0) {
                                    // Nascondi le sottocategorie se non ci sono categorie selezionate
                                    subcategoriesGroup.style.display = 'none';
                                    jQuery(subcategoriesSelect).empty().trigger('change');
                                    return;
                                }
                                
                                // Mostra loading
                                subcategoriesGroup.style.display = 'block';
                                jQuery(subcategoriesSelect).empty().append('<option value="">Caricamento...</option>').trigger('change');
                                
                                // Chiamata AJAX per ottenere le sottocategorie filtrate
                                jQuery.ajax({
                                    url: edunews_admin.ajax_url,
                                    type: 'POST',
                                    data: {
                                        action: 'edunews_get_subcategories_by_category',
                                        nonce: edunews_admin.nonce,
                                        categories: selectedCategories
                                    },
                                    success: function(response) {
                                        if (response.success) {
                                            // Svuota le opzioni e riempie con le nuove sottocategorie
                                            jQuery(subcategoriesSelect).empty();
                                            
                                            if (response.data.subcategories.length > 0) {
                                                jQuery.each(response.data.subcategories, function(index, subcategory) {
                                                    jQuery(subcategoriesSelect).append(
                                                        '<option value="' + subcategory.slug + '">' + subcategory.name + '</option>'
                                                    );
                                                });
                                            } else {
                                                jQuery(subcategoriesSelect).append('<option value="" disabled>Nessuna sottocategoria disponibile</option>');
                                            }
                                            
                                            jQuery(subcategoriesSelect).trigger('change');
                                        } else {
                                            console.error('Errore nel caricamento delle sottocategorie:', response.data);
                                            jQuery(subcategoriesSelect).empty().append('<option value="" disabled>Errore nel caricamento</option>').trigger('change');
                                        }
                                    },
                                    error: function(xhr, status, error) {
                                        console.error('Errore AJAX:', error);
                                        jQuery(subcategoriesSelect).empty().append('<option value="" disabled>Errore nel caricamento</option>').trigger('change');
                                    }
                                });
                            });
                        }
                    });
                </script>
            </div>
            
            <div class="edunews-card" style="flex: 2; min-width: 600px;">
                <h2>Configurazioni Shortcode Salvate</h2>
                <p class="description">Questa è una lista delle configurazioni create, utile per copiare rapidamente lo shortcode da incollare nelle pagine o negli articoli. Eliminare una configurazione da questa lista non influenzerà gli shortcode già inseriti nel sito.</p>
                
                <?php if (empty($saved_shortcodes)) : ?>
                    <p>Nessuna configurazione salvata. Creane una nuova usando il form a sinistra.</p>
                <?php else : ?>
                    <style>
                        /* Layout responsivo per le due colonne */
                        @media (max-width: 1200px) {
                            .edunews-admin-content {
                                flex-direction: column !important;
                            }
                            .edunews-card {
                                min-width: unset !important;
                            }
                        }
                        /* Container responsivo per la tabella */
                        .edunews-table-container {
                            overflow-x: auto;
                            margin: 15px 0;
                            border: 1px solid #ddd;
                            border-radius: 4px;
                        }
                        
                        .edunews-shortcode-table {
                            table-layout: auto;
                            width: 100%;
                            min-width: 800px; /* Larghezza minima per mantenere leggibilità */
                            border-collapse: collapse;
                        }
                        
                        .edunews-shortcode-table th,
                        .edunews-shortcode-table td {
                            padding: 12px 8px;
                            vertical-align: top;
                            border-bottom: 1px solid #eee;
                            text-align: left;
                        }
                        
                        .edunews-shortcode-table th {
                            background-color: #f9f9f9;
                            font-weight: 600;
                            border-bottom: 2px solid #ddd;
                        }
                        
                        /* Stili specifici per colonna - responsive */
                        .edunews-shortcode-table th:nth-child(1), /* Nome */
                        .edunews-shortcode-table td:nth-child(1) {
                            width: 120px;
                            min-width: 100px;
                            white-space: nowrap;
                            overflow: hidden;
                            text-overflow: ellipsis;
                        }
                        
                        .edunews-shortcode-table th:nth-child(2), /* Titolo */
                        .edunews-shortcode-table td:nth-child(2) {
                            width: 120px;
                            min-width: 100px;
                            white-space: nowrap;
                            overflow: hidden;
                            text-overflow: ellipsis;
                        }
                        
                        .edunews-shortcode-table th:nth-child(3), /* Visualizzazione */
                        .edunews-shortcode-table td:nth-child(3) {
                            width: 100px;
                            min-width: 80px;
                            white-space: nowrap;
                        }
                        
                        .edunews-shortcode-table th:nth-child(4), /* Categorie */
                        .edunews-shortcode-table td:nth-child(4) {
                            width: 120px;
                            min-width: 100px;
                            white-space: nowrap;
                        }
                        
                        .edunews-shortcode-table th:nth-child(5), /* Sottocategorie */
                        .edunews-shortcode-table td:nth-child(5) {
                            width: 140px;
                            min-width: 120px;
                            white-space: nowrap;
                        }
                        
                        .edunews-shortcode-table th:nth-child(6), /* N° Articoli */
                        .edunews-shortcode-table td:nth-child(6) {
                            width: 80px;
                            min-width: 60px;
                            text-align: center;
                            white-space: nowrap;
                        }
                        
                        .edunews-shortcode-table th:nth-child(7), /* Shortcode - IMPORTANTE: qui usiamo scroll! */
                        .edunews-shortcode-table td:nth-child(7) {
                            width: 280px;
                            min-width: 250px;
                            max-width: 350px;
                        }
                        
                        .edunews-shortcode-table th:nth-child(8), /* Azioni */
                        .edunews-shortcode-table td:nth-child(8) {
                            width: 80px;
                            min-width: 70px;
                            text-align: center;
                        }
                        
                        /* Stile specifico per la cella dello shortcode - con scroll orizzontale */
                        .shortcode-cell {
                            position: relative;
                        }
                        
                        /* Stili specifici per le celle scrollabili (categorie, sottocategorie) */
                        .categories-cell,
                        .subcategories-cell {
                            position: relative;
                        }
                        
                        .categories-text,
                        .subcategories-text {
                            white-space: nowrap;
                            overflow-x: auto;
                            overflow-y: hidden;
                            max-width: 100%;
                            padding: 2px 4px;
                            border-radius: 2px;
                            /* Scrollbar sottile per Firefox */
                            scrollbar-width: thin;
                            scrollbar-color: #ccc transparent;
                        }
                        
                        /* Scrollbar sottile per Chrome/Safari */
                        .categories-text::-webkit-scrollbar,
                        .subcategories-text::-webkit-scrollbar {
                            height: 3px;
                        }
                        
                        .categories-text::-webkit-scrollbar-track,
                        .subcategories-text::-webkit-scrollbar-track {
                            background: transparent;
                        }
                        
                        .categories-text::-webkit-scrollbar-thumb,
                        .subcategories-text::-webkit-scrollbar-thumb {
                            background: #ccc;
                            border-radius: 2px;
                        }
                        
                        .categories-text::-webkit-scrollbar-thumb:hover,
                        .subcategories-text::-webkit-scrollbar-thumb:hover {
                            background: #999;
                        }
                        
                        /* Stili per la colonna shortcode */
                        .shortcode-text {
                            font-family: 'Courier New', Courier, monospace;
                            font-size: 11px;
                            background: #f8f8f8;
                            border: 1px solid #ddd;
                            padding: 6px 8px;
                            border-radius: 3px;
                            display: block;
                            margin-bottom: 6px;
                            white-space: nowrap;
                            overflow-x: auto;
                            overflow-y: hidden;
                            max-width: 100%;
                            word-break: keep-all;
                            /* Scrollbar sottile per Firefox */
                            scrollbar-width: thin;
                            scrollbar-color: #ccc transparent;
                        }
                        
                        /* Scrollbar per shortcode su Chrome/Safari */
                        .shortcode-text::-webkit-scrollbar {
                            height: 4px;
                        }
                        
                        .shortcode-text::-webkit-scrollbar-track {
                            background: transparent;
                        }
                        
                        .shortcode-text::-webkit-scrollbar-thumb {
                            background: #ccc;
                            border-radius: 2px;
                        }
                        
                        .shortcode-text::-webkit-scrollbar-thumb:hover {
                            background: #999;
                        }
                        
                        .copy-shortcode {
                            font-size: 11px;
                            padding: 3px 8px;
                        }
                        
                        /* Tooltip per mostrare il testo completo al hover nelle altre colonne */
                        .edunews-shortcode-table td[title]:not(.shortcode-cell):not(.categories-cell):not(.subcategories-cell) {
                            cursor: help;
                        }
                        
                        /* Responsive per schermi piccoli */
                        @media (max-width: 1200px) {
                            .edunews-shortcode-table th:nth-child(7),
                            .edunews-shortcode-table td:nth-child(7) {
                                width: 220px;
                                min-width: 200px;
                            }
                        }
                        
                        @media (max-width: 768px) {
                            .edunews-table-container {
                                margin: 10px -15px; /* Estende ai bordi su mobile */
                                border-radius: 0;
                                border-left: none;
                                border-right: none;
                            }
                            
                            .edunews-shortcode-table {
                                min-width: 700px; /* Ridotto per mobile */
                            }
                            
                            .edunews-shortcode-table th,
                            .edunews-shortcode-table td {
                                padding: 8px 6px;
                                font-size: 14px;
                            }
                            
                            .shortcode-text {
                                font-size: 10px;
                                padding: 4px 6px;
                            }
                        }
                        
                    </style>
                    <div class="edunews-table-container">
                    <table class="wp-list-table widefat fixed striped edunews-shortcode-table">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Titolo</th>
                                <th>Visualizzazione</th>
                                <th>Categorie</th>
                                <th>Sottocategorie</th>
                                <th>N° Articoli</th>
                                <th>Shortcode Generato</th>
                                <th>Azioni</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($saved_shortcodes as $id => $shortcode) : 
                                // Ricostruiamo lo shortcode senza ID ma con gli attributi
                                $shortcode_tag = '[edunews_articles';
                                if (!empty($shortcode['title'])) {
                                    $shortcode_tag .= ' title="' . esc_attr($shortcode['title']) . '"';
                                }
                                if (!empty($shortcode['display_mode'])) {
                                    $shortcode_tag .= ' display_mode="' . esc_attr($shortcode['display_mode']) . '"';
                                }
                                if (!empty($shortcode['categories']) && is_array($shortcode['categories'])) {
                                    $categories_str = implode(',', $shortcode['categories']);
                                    $shortcode_tag .= ' categories="' . esc_attr($categories_str) . '"';
                                }
                                if (!empty($shortcode['subcategories']) && is_array($shortcode['subcategories'])) {
                                    $subcategories_str = implode(',', $shortcode['subcategories']);
                                    $shortcode_tag .= ' subcategories="' . esc_attr($subcategories_str) . '"';
                                }
                                // Modifichiamo qui: Aggiungiamo sempre max_posts
                                $max_posts_value = isset($shortcode['max_posts']) ? intval($shortcode['max_posts']) : 10;
                                
                                // Controlliamo se è impostato per mostrare tutti gli articoli
                                $show_all = isset($shortcode['show_all']) && $shortcode['show_all'] || $max_posts_value === 0;
                                
                                // Aggiungiamo max_posts allo shortcode solo se non è impostato per mostrare tutti
                                if (!$show_all) {
                                    $shortcode_tag .= ' max_posts="' . esc_attr($max_posts_value) . '"';
                                }
                                
                                $shortcode_tag .= ']';
                                
                                // Definisci display_mode_label
                                        $display_mode_label = 'Slider';
                                        if (!empty($shortcode['display_mode'])) {
                                            switch ($shortcode['display_mode']) {
                                                case 'grid':
                                                    $display_mode_label = 'Griglia';
                                                    break;
                                                case 'list':
                                                    $display_mode_label = 'Elenco';
                                                    break;
                                                default:
                                                    $display_mode_label = 'Slider';
                                            }
                                        }
                            ?>
                                <tr>
                                    <td title="<?php echo esc_attr($shortcode['name']); ?>"><?php echo esc_html($shortcode['name']); ?></td>
                                    <td title="<?php echo esc_attr(!empty($shortcode['title']) ? $shortcode['title'] : 'Nessuno'); ?>"><?php echo !empty($shortcode['title']) ? esc_html($shortcode['title']) : '<em>Nessuno</em>'; ?></td>
                                    <td title="<?php echo esc_attr($display_mode_label); ?>"><?php echo esc_html($display_mode_label); ?></td>
                                    <td class="categories-cell">
                                        <div class="categories-text">
                                        <?php 
                                        if (!empty($shortcode['categories']) && is_array($shortcode['categories'])) {
                                            echo esc_html(implode(', ', $shortcode['categories']));
                                        } else {
                                            echo '<em>Tutte</em>';
                                        }
                                        ?>
                                        </div>
                                    </td>
                                    <td class="subcategories-cell">
                                        <div class="subcategories-text">
                                        <?php 
                                        if (!empty($shortcode['subcategories']) && is_array($shortcode['subcategories'])) {
                                            echo esc_html(implode(', ', $shortcode['subcategories']));
                                        } else {
                                            echo '<em>Nessuna</em>';
                                        }
                                        ?>
                                        </div>
                                    </td>
                                    <td title="<?php echo $show_all ? 'Tutti gli articoli' : $max_posts_value . ' articoli'; ?>">
                                        <?php echo $show_all ? '<strong>Tutti</strong>' : esc_html($max_posts_value); ?>
                                    </td>
                                    <td class="shortcode-cell">
                                        <code class="shortcode-text"><?php echo esc_html($shortcode_tag); ?></code>
                                        <button class="button button-small copy-shortcode" data-shortcode="<?php echo esc_attr($shortcode_tag); ?>">Copia</button>
                                    </td>
                                    <td>
                                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=edunews-shortcode&action=delete&shortcode_id=' . $id), 'delete_shortcode_' . $id); ?>" class="button button-small button-link-delete" onclick="return confirm('Sei sicuro di voler eliminare questa configurazione?');">Elimina</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    </div>
                <?php endif; ?>
            </div>


        </div>
    </div>
    <?php
}


function edunews_get_categories() {
    #error_log('EduNews: Starting edunews_get_categories function');
    
    $categories = get_transient('edunews_categories_cache');
    #error_log('EduNews: Categories from cache: ' . print_r($categories, true));
    
    if ($categories === false || !is_array($categories) || count($categories) === 0) {
        #error_log('EduNews: No categories in cache or cache empty, fetching from WordPress');
        // Ora prendiamo solo le categorie principali (parent = 0)
        $wp_categories = get_terms(array(
            'taxonomy' => 'edunews_category',
            'hide_empty' => false,
            'parent' => 0, // Solo categorie principali
        ));
        if (!is_wp_error($wp_categories)) {
            $categories = array();
            foreach ($wp_categories as $cat) {
                $categories[] = array(
                    'term_id' => $cat->term_id,
                    'name' => $cat->name,
                    'slug' => $cat->slug
                );
            }
            set_transient('edunews_categories_cache', $categories, 2 * MINUTE_IN_SECONDS);
        } else {
            #error_log('EduNews: get_terms error: ' . $wp_categories->get_error_message());
            $categories = array();
    }
    }
    return $categories;
}


function edunews_get_subcategories() {
    #error_log('EduNews: Starting edunews_get_subcategories function');
    
    $subcategories = get_transient('edunews_subcategories_cache');
    #error_log('EduNews: Subcategories from cache: ' . print_r($subcategories, true));
    
    if ($subcategories === false || !is_array($subcategories) || count($subcategories) === 0) {
        #error_log('EduNews: No subcategories in cache or cache empty, fetching from WordPress');
        // Ora le sottocategorie sono termini figli nella tassonomia edunews_category (parent > 0)
        $wp_subcategories = get_terms(array(
            'taxonomy' => 'edunews_category',
            'hide_empty' => false,
            'parent' => 0, // Escludiamo le categorie principali
            'exclude' => array() // Funzione inversa: includiamo solo quelli con parent > 0
        ));
        
        // Filtriamo manualmente per ottenere solo i termini con parent > 0
        $all_terms = get_terms(array(
            'taxonomy' => 'edunews_category',
            'hide_empty' => false,
        ));
        
        if (!is_wp_error($all_terms)) {
            $subcategories = array();
            foreach ($all_terms as $term) {
                // Solo termini che hanno un parent (sottocategorie)
                if ($term->parent > 0) {
                    $subcategories[] = array(
                        'term_id' => $term->term_id,
                        'name' => $term->name,
                        'slug' => $term->slug,
                        'parent' => $term->parent
                    );
                }
            }
            set_transient('edunews_subcategories_cache', $subcategories, 2 * MINUTE_IN_SECONDS);
        } else {
            #error_log('EduNews: get_terms error for subcategories: ' . $all_terms->get_error_message());
            $subcategories = array();
        }
    }
    return $subcategories;
}


function edunews_get_articles() {
    #error_log('EduNews: Getting articles from cache');
    
    $articles = get_transient('edunews_articles_cache');
    
    if ($articles === false) {
        #error_log('EduNews: No articles in cache, waiting for background update');
        return array();
    }
    
    #error_log('EduNews: Found ' . count($articles) . ' articles in cache');
    return $articles;
}


add_action('wp_ajax_edunews_get_shortcode_posts', 'edunews_get_shortcode_posts');
function edunews_get_shortcode_posts() {
    check_ajax_referer('edunews_admin_nonce', 'nonce');
    
    $shortcode_id = isset($_POST['shortcode_id']) ? sanitize_text_field($_POST['shortcode_id']) : '';
    
    if (empty($shortcode_id)) {
        wp_send_json_error(['message' => 'ID shortcode mancante']);
        return;
    }
    
    $saved_shortcodes = get_option('edunews_saved_shortcodes', []);
    
    if (!isset($saved_shortcodes[$shortcode_id])) {
        wp_send_json_error(['message' => 'Shortcode non trovato']);
        return;
    }
    
    $post_ids = isset($saved_shortcodes[$shortcode_id]['post_ids']) ? $saved_shortcodes[$shortcode_id]['post_ids'] : [];
    
    wp_send_json_success([
        'post_ids' => $post_ids,
        'shortcode' => $saved_shortcodes[$shortcode_id]
    ]);
}


add_action('wp_ajax_edunews_search_posts', 'edunews_search_posts');
function edunews_search_posts() {
    check_ajax_referer('edunews_admin_nonce', 'nonce');
    
    $search_term = isset($_POST['search_term']) ? sanitize_text_field($_POST['search_term']) : '';
    
    if (empty($search_term)) {
        wp_send_json_success(array(
            'posts' => edunews_get_articles()
        ));
        return;
    }
    
    $all_articles = edunews_get_articles();
    $search_term = strtolower($search_term);
    
    $filtered_articles = array_filter($all_articles, function($article) use ($search_term) {
        return strpos(strtolower($article['title']), $search_term) !== false;
    });
    
    wp_send_json_success(array(
        'posts' => array_values($filtered_articles)
    ));
}


add_action('wp_ajax_edunews_update_shortcode_posts', 'edunews_update_shortcode_posts');
function edunews_update_shortcode_posts() {
    check_ajax_referer('edunews_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Permessi insufficienti']);
        return;
    }
    
    $shortcode_id = isset($_POST['shortcode_id']) ? sanitize_text_field($_POST['shortcode_id']) : '';
    $post_ids = isset($_POST['post_ids']) ? array_map('sanitize_text_field', $_POST['post_ids']) : [];
    
    if (empty($shortcode_id)) {
        wp_send_json_error(['message' => 'ID shortcode mancante']);
        return;
    }
    
    $saved_shortcodes = get_option('edunews_saved_shortcodes', []);
    
    if (!isset($saved_shortcodes[$shortcode_id])) {
        wp_send_json_error(['message' => 'Shortcode non trovato']);
        return;
    }
    

    $saved_shortcodes[$shortcode_id]['post_ids'] = $post_ids;
    

    update_option('edunews_saved_shortcodes', $saved_shortcodes);
    
    wp_send_json_success(['message' => 'Post aggiornati con successo']);
}


add_action('wp_ajax_edunews_get_filtered_articles', 'edunews_get_filtered_articles');
function edunews_get_filtered_articles() {
    check_ajax_referer('edunews_admin_nonce', 'nonce');
    
    $category = isset($_POST['category']) ? sanitize_text_field($_POST['category']) : '';
    
    $all_articles = edunews_get_articles();
    
    // Debug log for search
    #error_log('EduNews Category Search: ' . $category);
    #error_log('EduNews Total Articles: ' . count($all_articles));
    
    if (!empty($category) && is_array($all_articles)) {
        $category = strtolower(trim($category));
        $all_articles = array_filter($all_articles, function($article) use ($category) {
            if (!isset($article['category_slug']) || !isset($article['category'])) {
                #error_log('EduNews Article missing category data: ' . print_r($article, true));
                return false;
            }
            
            $article_category = strtolower($article['category']);
            $article_category_slug = strtolower($article['category_slug']);
            
            #error_log('EduNews Comparing: ' . $category . ' with ' . $article_category . ' or ' . $article_category_slug);
            
            return (strpos($article_category, $category) !== false ||
                   strpos($article_category_slug, $category) !== false);
        });
        
        #error_log('EduNews Filtered Articles Count: ' . count($all_articles));
    }
    
    $all_articles = array_values($all_articles);
    
    ob_start();
    include plugin_dir_path(__FILE__) . 'templates/admin-articles.php';
    $html = ob_get_clean();
    
    wp_send_json_success(array(
        'html' => $html,
        'count' => count($all_articles)
    ));
}


add_action('wp_ajax_edunews_update_shortcode_title', 'edunews_update_shortcode_title');
function edunews_update_shortcode_title() {
    check_ajax_referer('edunews_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Permessi insufficienti']);
        return;
    }
    
    $shortcode_id = isset($_POST['shortcode_id']) ? sanitize_text_field($_POST['shortcode_id']) : '';
    $new_title = isset($_POST['title']) ? sanitize_text_field($_POST['title']) : '';
    
    if (empty($shortcode_id)) {
        wp_send_json_error(['message' => 'ID shortcode mancante']);
        return;
    }
    
    $saved_shortcodes = get_option('edunews_saved_shortcodes', []);
    
    if (!isset($saved_shortcodes[$shortcode_id])) {
        wp_send_json_error(['message' => 'Shortcode non trovato']);
        return;
    }
    

    $saved_shortcodes[$shortcode_id]['title'] = $new_title;
    

    update_option('edunews_saved_shortcodes', $saved_shortcodes);
    
    wp_send_json_success([
        'message' => 'Titolo aggiornato con successo',
        'new_title' => $new_title
    ]);
}

add_action('wp_ajax_edunews_update_shortcode_settings', 'edunews_update_shortcode_settings');
function edunews_update_shortcode_settings() {
    check_ajax_referer('edunews_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Permessi insufficienti']);
        return;
    }
    
    $shortcode_id = isset($_POST['shortcode_id']) ? sanitize_text_field($_POST['shortcode_id']) : '';
    $name = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
    $title = isset($_POST['title']) ? sanitize_text_field($_POST['title']) : '';
    $display_mode = isset($_POST['display_mode']) ? sanitize_text_field($_POST['display_mode']) : 'slide';
    $categories = isset($_POST['categories']) ? array_map('sanitize_text_field', $_POST['categories']) : [];
    $subcategories = isset($_POST['subcategories']) ? array_map('sanitize_text_field', $_POST['subcategories']) : [];
    
    if (empty($shortcode_id) || empty($name)) {
        wp_send_json_error(['message' => 'Dati mancanti o incompleti']);
        return;
    }
    
    $saved_shortcodes = get_option('edunews_saved_shortcodes', []);
    
    if (!isset($saved_shortcodes[$shortcode_id])) {
        wp_send_json_error(['message' => 'Shortcode non trovato']);
        return;
    }

    $saved_shortcodes[$shortcode_id]['name'] = $name;
    $saved_shortcodes[$shortcode_id]['title'] = $title;
    $saved_shortcodes[$shortcode_id]['display_mode'] = $display_mode;
    $saved_shortcodes[$shortcode_id]['categories'] = $categories;
    $saved_shortcodes[$shortcode_id]['subcategories'] = $subcategories;
    
    // Salva le modifiche
    update_option('edunews_saved_shortcodes', $saved_shortcodes);
    
    wp_send_json_success([
        'message' => 'Shortcode aggiornato con successo'
    ]);
}

// Funzione AJAX per ottenere sottocategorie filtrate per categoria
add_action('wp_ajax_edunews_get_subcategories_by_category', 'edunews_get_subcategories_by_category');
function edunews_get_subcategories_by_category() {
    check_ajax_referer('edunews_admin_nonce', 'nonce');
    
    $selected_categories = isset($_POST['categories']) ? array_map('sanitize_text_field', $_POST['categories']) : [];
    
    #error_log('EduNews: Getting subcategories for categories: ' . print_r($selected_categories, true));
    
    if (empty($selected_categories)) {
        wp_send_json_success(['subcategories' => []]);
        return;
    }
    
    // Ottieni gli ID delle categorie selezionate
    $category_ids = [];
    foreach ($selected_categories as $category_slug) {
        $term = get_term_by('slug', $category_slug, 'edunews_category');
        if ($term && !is_wp_error($term)) {
            $category_ids[] = $term->term_id;
        }
    }
    
    #error_log('EduNews: Category IDs: ' . print_r($category_ids, true));
    
    if (empty($category_ids)) {
        wp_send_json_success(['subcategories' => []]);
        return;
    }
    
    // Recupera le sottocategorie che sono figlie delle categorie selezionate
    $filtered_subcategories = [];
    $all_subcategories = edunews_get_subcategories();
    
    foreach ($all_subcategories as $subcategory) {
        // Verifica se questa sottocategoria ha come parent una delle categorie selezionate
        if (in_array($subcategory['parent'], $category_ids)) {
            $filtered_subcategories[] = $subcategory;
        }
    }
    
    #error_log('EduNews: Found ' . count($filtered_subcategories) . ' subcategories for selected categories');
    
    wp_send_json_success(['subcategories' => $filtered_subcategories]);
} 